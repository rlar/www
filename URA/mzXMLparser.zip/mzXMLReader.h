#ifndef __MZXMLREADER_H__
#define __MZXMLREADER_H__

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

class mzXMLreader{
		public:
			int parse(std::string filename /*, int * arr1, int * arr2 */ );
};

#endif
