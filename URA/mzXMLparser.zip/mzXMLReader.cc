#include "mzXMLReader.h"
#include "base64.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <map>

#define FLDEBUG 1

using namespace std;

int getIndexOffset(string filename, int *offset);
int parseIndex(string filename, map<int,int> * mapIndex, int indexOffset);

int mzXMLreader::parse(string filename /*, int * arr1, int * arr2 */ )
{
	int nScans = -1,
		offset = -1,
		err = 0;
		
	map<int,int> mapIndex;
	
	if (FLDEBUG) cout << "parsing..." << endl
					  << "parsing index offset..." << endl;
	
	// determine the offset of the index of the file
	if ( getIndexOffset(filename, &offset) )
	{
		// an error occured, which was reported in getIndexOffset
		return 1;
	}
	
	if (FLDEBUG) cout << "index offset is " << offset << "..." << endl
					  << "parsing scan offsets from index..." << endl;
	
	// parse the index into an associative map to retrieve scan offsets
	if ( parseIndex(filename, &mapIndex, offset) )
	{
		// an error occured, which was reported in getIndexOffset
		return 2;
	}
	
	
	return 0;
}

/// an xml parser would be ideal for this job, but the following function
/// should be fine as is. future enhancement
int getIndexOffset(string filename, int *offset)
{
	ifstream inf;
    char 	buffer[200];
    string 	line				= "",
			indexOffset			= "<indexOffset>",
			indexOffsetClose	= "</indexOffset>";
	size_t 	found, 
			found2;
			
	stringstream 	ss (stringstream::in | stringstream::out);
	
	// try to open the file to extract the offset of the index block
	inf.open( filename.c_str(), ifstream::in );
	
	if (!inf)
    {
        cerr << "getIndexOffset: couldn't open " << filename << endl;
        return -1;
    }
    
    // move to the end of the file and try to find the index offset
	/* NOTE: tail should resemble 
	    </index>
		<indexOffset>127618357</indexOffset>
		<sha1>d2a04eebb2c0984062eb9ad1dc7d844ac58e2456</sha1>
		</mzXML>
		as long as sha-1 codes are all the same bitlength
	*/
	
    inf.seekg(-200,ios::end);
    inf.read(buffer, 200);
    line = buffer;
    
    found = line.find(indexOffset);
    
    if (found == string::npos )
    {
        cerr << "getIndexOffset: couldn't find the <index> of " << filename << endl;
        return 1;
	}
	
	// go to the index of the mzXML
	found2 = line.find(indexOffsetClose);
	
	if (found2 == string::npos )
    {
        cerr << "getIndexOffset: couldnt find </indexOffset> tag of " << filename << endl;
        return 1;
	}
	
	// extract and parse the index offset in bytes
	int start = found + indexOffset.size();
	int len = found2 - found + indexOffset.size();
	ss << line.substr( start, len );
	
	ss >> *offset;
	        
	inf.close();
	return 0;
    
    /*   the snippet below is so i remember how to do random access reading
    // Get the rest of the line and print it
    getline(inf, line);
    cout << strData << endl;

    inf.seekg(8, ios::cur); // move 8 more bytes into file
    // Get rest of the line and print it
    getline(inf, strData);
    cout << strData << endl;

    inf.seekg(-15, ios::end); // move 15 bytes before end of file
    // Get rest of the line and print it
    getline(inf, strData);
    cout << strData << endl;
    */
}

int parseIndex(string filename, map<int,int> * mapIndex, int indexOffset)
{
	ifstream inf;
    char 	buffer[256];
    string 	line			= "",
			indexOpen		= "<index name=\"scan\" >",
			offsetOpen		= "<offset id=\"",
			offsetClose		= "</offset>",
			indexClose		= "</index>";
			
	stringstream ss (stringstream::in | stringstream::out);
	
	// try to open the file to parse the index
	inf.open( filename.c_str(), ifstream::in );
	
	if (!inf)
    {
        cerr << "parseIndex: couldn't open " << filename << endl;
        return -1;
    }
    
    // move to the start of the index
    inf.seekg(indexOffset,ios::beg);
    inf.getline(buffer,256);
    line = buffer;
    
    cout << "index line is: " << endl << line << endl;
    
    if (line.find(indexOpen); == string::npos )
    {
        cerr << "parseIndex: <index> tag malformed" << endl;
        return 2;
	}
	
	// loop through the index, and parse out each scans offset
	inf.getline(buffer,256);
    line = buffer;
	while ( line.find(indexOffset) == string::npos )
	{
		
		
		// go to next line
		inf.getline(buffer,256);
		line = buffer;
	} 
	
	// extract and parse the index offset in bytes
	int start = found + indexOffset.size();
	int len = found2 - found + indexOffset.size();
	ss << line.substr( start, len );
	
	ss >> *offset;
	        
	inf.close();
	return 0;
	*/
	return 0;
}
