#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "mzXMLReader.h"

#define FLDEBUG 1

using namespace std;


int main(int argc, char** argv)
{
	int 		err			= 0;
	string 		filename 	= "";
	mzXMLreader reader;
	
	
	if (FLDEBUG) cout << "running main..." << endl;
	
	// attempt to open the mzXML file
	if (argc < 2)
	{
        cerr << "Please provide the name of an mzXML file to be parsed" << endl;
        return 1;
    }
    
    filename = argv[1];
    
    if (FLDEBUG) cout << "opening " << filename << "..." << endl;
	reader.parse( filename );

	return 0;
}

