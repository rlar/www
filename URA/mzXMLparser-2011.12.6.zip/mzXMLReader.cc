#include "mzXMLReader.h"
#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <sstream>
#include <map>
#include <stdlib.h>
#include "spectrum.h"
#include <vector>
#include <iomanip>

#define FLDEBUG 1 // 1 to print debug output
#define BYTEORDER_LITTLE_ENDIAN 0 // 1 if this machine is little endian
#define RTTOL 10 // +- retention time tolerance (in minutes)
#define MZTOL .5 // +- mz tolerance
#define PEAKRATIO .5 // if (height of this peak)/(highestPeak) < PEAKRATIO, disregard peak 

using namespace std;

// all functions return an error code based on their success, 0=successful
// (except Parse___FromXML)
int getIndexOffset(string filename, int *offset);
int parseIndex(string filename, map<int,int> * mapIndex, int indexOffset);
int loopThruvecScans(string filename, vector<int> *vecScans, 
                     map<int,int> * mapIndex, int indexOffset);
int fillSpectrumFromMZXML(FILE *mzxml_stream, int bufflen, spectrum * spec);
int get_peak_list_from_MZXML(FILE *mzxml_stream, int bufflen, spectrum * spec);
float ParseFloatFromXML(char* AttributeString);
int findRelatedSpectra(string filename, map<int,int> * mapIndex, float targetMZ, 
                       float targetRT, vector<float> *vecRT);
int parseMZandRT(char* buffer, float *mz, float *rt);




int mzXMLreader::parse(string filename, vector<int> *vecScans)
{
    int nScans      = -1,
        indexOffset = -1,
        err         = 0;
        
    // to map <scan> # to byte offset into mzXML
    map<int,int> mapIndex; 
    
    if (FLDEBUG) cout << "parsing..." << endl
                      << "parsing index offset..." << endl;
    
    // determine the offset of the index of the file
    if ( getIndexOffset(filename, &indexOffset) )
    {
        return 1;
    }
    
    if (FLDEBUG) cout << "index offset is " << indexOffset << endl;
    
    // this program can only parse based on index entries
    if (indexOffset == 0)
    {
        cerr << "No index present in mzXML, cannot parse! " << endl;
        return 0;
    }
    
    if (FLDEBUG) cout << "parsing scan offsets from index..." << endl;
                      
    // parse the index into an associative map to retrieve scan offsets
    if ( parseIndex(filename, &mapIndex, indexOffset) )
    {
        return 2;
    }
    
    if (FLDEBUG) cout << "found offsets for " << mapIndex.size() 
                      << " scans" << endl
                      << "looping through scanList..." << endl;
                      
    // for each scan in vecScans, check  which of other tandem mass 
    // spectrum scans have the same precursor mass within 10 mins before
    // and after its retention time, and get statistics on the retention
    // times of those other scans
    if ( loopThruvecScans(filename, vecScans, &mapIndex, indexOffset) )
    {
        return 3;
    }
    
    return 0;
}




int getIndexOffset(string filename, int *offset)
{
    ifstream inf;
    char     buffer[200];
    string   line                = "",
             indexOffset         = "<indexOffset>",
             indexOffsetClose    = "</indexOffset>";
    size_t   found, 
             found2;
            
    // try to open the file to extract the offset of the index block
    inf.open( filename.c_str(), ifstream::in );
    
    if (!inf)
    {
        cerr << "getIndexOffset: couldn't open " << filename << endl;
        return -1;
    }
    
    // move to the end of the file and try to find the index offset
    /* NOTE: tail should resemble 
        </index>
        <indexOffset>127618357</indexOffset>
        <sha1>d2a04eebb2c0984062eb9ad1dc7d844ac58e2456</sha1>
        </mzXML>
    */
    
    inf.seekg(-200,ios::end);
    inf.read(buffer, 200);
    line = buffer;
    
    found = line.find(indexOffset);
    
    if (found == string::npos )
    {
        cerr << "getIndexOffset: couldn't find the <index> of " << filename << endl;
        return 1;
    }
    
    // go to the index of the mzXML
    found2 = line.find(indexOffsetClose);
    
    if (found2 == string::npos )
    {
        cerr << "getIndexOffset: couldnt find </indexOffset> tag of " << filename << endl;
        return 1;
    }
    
    // extract and parse the index offset in bytes
    int start = found + indexOffset.size();
    int len = found2 - found + indexOffset.size();
    *offset = atoi( line.substr( start, len ).c_str() );
            
    inf.close();
    return 0;
}

// parseIndex: map scan # to byte offset into file
int parseIndex(string filename, map<int,int> * mapIndex, int indexOffset)
{
    ifstream inf;
    char     buffer[256];
    string   line            = "",
             indexOpen       = "<index name=\"scan\" >",
             offsetIDOpen    = "<offset id=\"",
             offsetIDClose   = "\" >",
             offsetClose     = "</offset>",
             indexClose      = "</index>";
    int      start           = 0,
             len             = 0,
             scan            = 0,
             offset          = 0;
            
    // try to open the file to parse the index
    inf.open( filename.c_str(), ifstream::in );
    
    if (!inf)
    {
        cerr << "parseIndex: couldn't open " << filename << endl;
        return 1;
    }
    
    // move to the start of the index
    inf.seekg(indexOffset,ios::beg);
    inf.getline(buffer,256);
    line = buffer;
    
    if (line.find(indexOpen) == string::npos )
    {
        cerr << "parseIndex: <index> tag malformed or wrong index offset" 
             << endl;
        return 2;
    }
    
    // loop through the index, and parse out each scans offset
    inf.getline(buffer,256);
    line = buffer;
    while ( line.find(indexClose) == string::npos )
    {
        // careful making assumptions about the index string format,
        // catch any errors
        try
        {
            // extract the scan ID
            start = line.find(offsetIDOpen) + offsetIDOpen.size();
            len = line.find(offsetIDClose) - start;
            scan = atoi( line.substr( start, len ).c_str() );
            
            // extract the scans offset
            start = line.find(offsetIDClose) + offsetIDClose.size();
            len = line.find(offsetClose) - start;
            offset = atoi( line.substr( start, len ).c_str() );
            
            // add this scan and offset pair to the map
            mapIndex->insert( pair<int,int>(scan,offset) );
        }
        catch (int e)
        {
            cerr << "Warning: an error occurred when parsing the " 
                 << "following line of the scan/offset index:" << endl
                 << line << endl;
        }
        
        // go to next line
        inf.getline(buffer,256);
        line = buffer;
    }

    // add a "dummy" entry to the end of the map that stores the offset
    // of the index, so that we can still calculate how many bytes to
    // read for the last scan entry
    mapIndex->insert( pair<int,int>(scan+1,indexOffset) );

    inf.close();
    return 0;
}


int loopThruvecScans(string filename, vector<int> *vecScans, 
                     map<int,int> * mapIndex, int indexOffset)
{
    int     i                 = 0,
            scanNum           = 0,
            offset            = 0,
            len               = 0,
            result            = 0;
    float   mean			  = 0,
			variance		  = 0;
    char    *buffer           = NULL,
            *found;
    string  scanOpen          = "<scan num=\"",
            peaksOpen         = "<peaks ",
            line              = "";
    ifstream inf;
    
    // open the mzXML file
    inf.open( filename.c_str(), ifstream::in );
    if ( !inf )
    {
        cerr << "loopThruvecScans: couldnt open " << filename << endl;
        return 1; 
    }
        
    // iterate through the vector of scan IDs, checking which of other tandem mass 
    // spectrum scans have the same precursor mass within 10 mins before
    // and after its retention time, and get statistics on the retention
    // times of those other scans
    for (i = 0; i < vecScans->size(); i++)
    {
		// set up new variables for this scan
        float         mz = 0,
                      rt = 0; 
        vector<float> vecRT;
        
        scanNum = (*vecScans)[i];
        
        // find the how many bytes into the mzXML this scans' data starts,
        // and how long it is ( length = offsetOfNextScan - offsetOfThisScan)
        offset = mapIndex->find( scanNum )->second;
        len = mapIndex->find( scanNum+1 )->second - offset;
        
        // move file pointer to start of scan block
        buffer= new char[len-1];
        
        // read this scan block into the buffer
        inf.seekg(offset,ios::beg);
        inf.read(buffer, len);
    
		// parse out precursorMZ and retention time for this scan  
		parseMZandRT(buffer, &mz, &rt);
		
        if (mz < 0)
        {
            cerr << "loopThruvecScans at scan " << scanNum << ": "
                     << "couldn't find precursorMZ!" << endl;
        }
        
        if (rt < 0)
        {
            cerr << "loopThruvecScans at scan " << scanNum << ": "
                 << "couldn't find retention time!" << endl;
        }
        
        if (mz < 0 || rt < 0)
			continue;
        
        
        if (FLDEBUG) cout << "scan " << scanNum << ": "
                          << fixed << setprecision(10)
                          << " mz=" << mz
                          << " rt=" << rt << endl;
        
        // check the other tandem mass spectrum scans for related scans
        findRelatedSpectra(filename, mapIndex, mz, rt, &vecRT);
        
        if ( vecRT.size() > 0 )
        {
			// calculate the mean and variance for the RT's in vecRT
			mean = 0;
			variance = 0;
			vector<float>::iterator it;
			
			for (it = vecRT.begin(); it != vecRT.end(); it++)
				mean += *it;
			mean /= vecRT.size();
			
			for (it = vecRT.begin(); it != vecRT.end(); it++)
				variance += (*it - mean)*(*it - mean);
			variance /= vecRT.size();
			
			// print this triplet for the user
			cout << "{" << mz << ", " << mean << ", "  << variance << "}" << endl;
		}
        else
        {
			cout << "{" << mz << ": no other spectra rt found}" << endl;
		}
        
        
        delete(buffer);
        if (result > 0)
        {
            cerr << "in buildVecScansSpectra: scan " << scanNum << endl;
        }
    }
    
    inf.close();
    
    return 0;
}

int findRelatedSpectra(string filename, map<int,int> * mapIndex, float targetMZ, 
                       float targetRT, vector<float> *vecRT)
{
	int len, offset, scanNum;
	float mz, rt;
	char* buffer = NULL;
	FILE *pFile = NULL;
	
	pFile = fopen ( filename.c_str() , "r" );
	
	if ( pFile==NULL )
	{
		cerr << "findRelatedSpectra: couldnt open " << filename << endl;
		return 1;
	}
	
	// loop through all spectra in the index (note, the last entry in
	// the map is actually the offset of the index, so dont check it)
	map< int,int>::const_iterator checkEnd;
	for ( map< int,int>::const_iterator iter = mapIndex->begin(); ; ++iter )
	{
		checkEnd = iter;
		if ( ++checkEnd == mapIndex->end() )
		{
			// don't check last entry in the map, so we're done
			break;
		}
		
		// set up file fields for this scan
		scanNum = iter->first;
		offset = iter->second;
		len =  checkEnd->second - offset;
		
		if (buffer != NULL) delete buffer;
		buffer = new char[len];

		fseek(pFile, offset, SEEK_SET);
		fread(buffer, len, sizeof(char), pFile);
		
		// skip non- tandem MS spectra
		if ( !strstr(buffer, "msLevel=\"2\"") )
			continue;
		
		// parse out precursorMZ and retention time for this scan  
		parseMZandRT(buffer, &mz, &rt);
		
		// (note, this will print once for each entry in scanvec.. should
		// change this if its a valuable check to run)
        if (mz < 0)
        {
            cerr << "findRelatedSpectra at scan " << scanNum << ": "
                     << "couldn't find precursorMZ!" << endl;
        }
        
        if (rt < 0)
        {
            cerr << "findRelatedSpectra at scan " << scanNum << ": "
                 << "couldn't find retention time!" << endl;
        }
        
        // skip erroneous scans
        if (mz < 0 || rt < 0)
			continue;
			
		// skip if this rt setting fails to meet our criteria
		if ( rt < targetRT - RTTOL || targetRT + RTTOL < rt)
		     continue;
		     
        // build a list of the peaks in this scan
        spectrum *spec = new spectrum();
        fseek(pFile, offset, SEEK_SET);
        if ( get_peak_list_from_MZXML(pFile,len,spec) )
        {
			cerr << "findRelatedSpectra: Error parsing peaks on scan " << scanNum << endl;
			delete(spec);
			continue;
		}
		
		// check for a peak in this scan with a suitable mz
		spec->highestPeak;
		for (int i = 0; i < spec->count; i++)
		{
			///cout << "scan " << scanNum << ": mz=" << spec->mzArr[i] << endl;
	
			if ( targetMZ - MZTOL <= spec->mzArr[i] && 
			     spec->mzArr[i] <= targetMZ + MZTOL &&
			     (spec->hArr[i]/spec->highestPeak) > PEAKRATIO )
			{
				// we've found a suitable peak, so store the RT for
				// this scan and move on
				vecRT->push_back(rt);
				break;
			}
		}
		
		delete(spec);
	}
	
	delete buffer;
	fclose(pFile);
	
	return 0;
}
                       
int parseMZandRT(char* buffer, float *mz, float *rt)
{
	string precursorMzOpen   = "<precursorMz",
           retentiontimeOpen = "retentionTime=\"PT";
           
	// parse out precursorMZ    
    char* found = strstr(buffer, precursorMzOpen.c_str());
	if (!found)
	{
		*mz = -1;
	}
	else
	{
		// find the closing brace > of the precusorMZ tag, and parse mz
		while (*found != '>') found++;
		*mz = ParseFloatFromXML(found);
	}
	
	// parse out retention time    
	found = strstr(buffer, retentiontimeOpen.c_str());
	if (!found)
	{
		*rt = -1;
	}
	else
	{
		*rt = ParseFloatFromXML(found);
	}
	
	if (*mz < 0 || *rt < 0)
		return 1;
	else
		return 0;
}                 
                       
                       
                       
                       
                       

// ******************** peaks parsing code from PepNovo's src/MZXML_parsing.cpp ********************
int ParseIntFromXML(char* AttributeString);
void b64_decode_mio ( char *dest,  char *src );

// from PepNovo source, modified to store the peaks information for a single
// scan (assumed mzxml_stream is already pointing at the start of this scan
// in the file, bufflen is the number of chars in this <scan> block
int get_peak_list_from_MZXML(FILE *mzxml_stream, int bufflen, spectrum * spec)
{
    static char* Buffer = NULL;
    char* PeakCountStr;
    int PeakCount;
    char* PeakStr;
    static char* PeakBuffer = NULL;
    static char* DecodedPeakBuffer = NULL;
    static float* Peaks = NULL;
    static int PeakBufferSize = 0;

    int PeakIndex;
    static char* PrecursorStr;
    int FloatIndex;
    char* ByteOrderStr;
    int ByteOrderLittle = 1;

    long start_pos = ftell(mzxml_stream);
    
    if (!Buffer)
    {
        Buffer = (char*)calloc(bufflen + 1, sizeof(char));
    }
    
    char *bf=Buffer;
    fread(Buffer, bufflen, sizeof(char), mzxml_stream);
    PeakCountStr = strstr(Buffer, "peaksCount=\"");
    if (!PeakCountStr)
    {
        cerr << "Error parsing peaks from mzxml " << endl;
        return 1;
    }
    PeakCount = ParseIntFromXML(PeakCountStr);
    
    // set up spec
    spec->count = PeakCount;
    spec->mzArr = new float[PeakCount];
    spec->hArr  = new float[PeakCount];
    
    if (!PeakCount)
    {
        // A spectrum with zero peaks!  This is aberrant, but it can happen,
        // so bail out politely.  
        cerr << "Error: mzXML spectrum contains no peaks" << endl;
        return 1;
    }

  
    PeakStr = strstr(Buffer, "<peaks");
    if (PeakStr)
    {
        // Get byte order:
        ByteOrderStr = strstr(PeakStr, "byteOrder=\"");
        if (ByteOrderStr)
        {
            ByteOrderStr += 11;
            if (!strncmp(ByteOrderStr, "network", 7))
            {
                ByteOrderLittle = 0;
            }
            if (!strncmp(ByteOrderStr, "big", 3))
            {
                ByteOrderLittle = 0;
            }
            if (!strncmp(ByteOrderStr, "little", 6))
            {
                ByteOrderLittle = 1;
            }
        }
        PeakStr = strstr(PeakStr, ">");
    }
    if (!PeakStr)
    {
        cerr << "Error parsing peaks from mzxml " << endl;
        return 1;
    }

    PeakStr++;
    if (PeakBufferSize < PeakCount)
    {
        if (PeakBuffer)
        {
            free(PeakBuffer);
            PeakBuffer = NULL;
            free(DecodedPeakBuffer);
            DecodedPeakBuffer = NULL;
            free(Peaks);
            Peaks = NULL;
        }
        PeakBufferSize = PeakCount;
        PeakBuffer = (char*)calloc(PeakBufferSize * 22 + 100, 1);
        DecodedPeakBuffer = (char*)calloc(PeakCount * 8 + 8, 1);
        Peaks = (float*)calloc(PeakCount * 2, sizeof(float));
    }

    char *pb = PeakBuffer;
    int pbs= PeakBufferSize;
    fseek(mzxml_stream, start_pos + (PeakStr - Buffer) +15, 0);
    fread(PeakBuffer, PeakBufferSize * 22 + 100, sizeof(char), mzxml_stream);
    int Trail = (PeakCount % 3);
    if (!(PeakCount % 3))
    {
        PeakBuffer[PeakCount * 32/3] = '\0';
    }
    else
    {
        PeakBuffer[(PeakCount * 32/3) + Trail + 1] = '\0';
    }
    
    b64_decode_mio( DecodedPeakBuffer, PeakBuffer);
    
    for (FloatIndex = 0; FloatIndex < (2 * PeakCount); FloatIndex++)
    {
#if BYTEORDER_LITTLE_ENDIAN
        if (!ByteOrderLittle)
        {
            char ByteSwap = DecodedPeakBuffer[FloatIndex*4];
            DecodedPeakBuffer[FloatIndex*4] = DecodedPeakBuffer[FloatIndex*4 + 3];
            DecodedPeakBuffer[FloatIndex*4 + 3] = ByteSwap;
            ByteSwap = DecodedPeakBuffer[FloatIndex*4 + 1];
            DecodedPeakBuffer[FloatIndex*4 + 1] = DecodedPeakBuffer[FloatIndex*4 + 2];
            DecodedPeakBuffer[FloatIndex*4 + 2] = ByteSwap;
        }
        memcpy(Peaks + FloatIndex, DecodedPeakBuffer + FloatIndex * 4, 4);
#else
        if (ByteOrderLittle)
        {
            char ByteSwap = DecodedPeakBuffer[FloatIndex*4];
            DecodedPeakBuffer[FloatIndex*4] = DecodedPeakBuffer[FloatIndex*4 + 3];
            DecodedPeakBuffer[FloatIndex*4 + 3] = ByteSwap;
            ByteSwap = DecodedPeakBuffer[FloatIndex*4 + 1];
            DecodedPeakBuffer[FloatIndex*4 + 1] = DecodedPeakBuffer[FloatIndex*4 + 2];
            DecodedPeakBuffer[FloatIndex*4 + 2] = ByteSwap;
        }
        memcpy(Peaks + FloatIndex, DecodedPeakBuffer + FloatIndex * 4, 4);
#endif
    }
   
    int i_pos=0;
    spec->highestPeak = 0;
    for (PeakIndex = 0; PeakIndex < PeakCount; PeakIndex++)
    {
        // store this peak in the spec, including mass/charge and intensity
        spec->mzArr[PeakIndex] = Peaks[i_pos++];
        spec->hArr[PeakIndex] = Peaks[i_pos++];
        
        // keep track of highest peak so we can judge which ones are insignificant
        if (spec->hArr[PeakIndex] > spec->highestPeak)
            spec->highestPeak = spec->hArr[PeakIndex];
    }
    /// *******************************************************************************************
    /// SANITY CHECK FAILING! have to figure out why PepNovo's 64-bit decoder code isnt
    /// working properly... negative masses, negative peaks being returned!
    ///  *******************************************************************************************
/*
    // sanity check
    int i;
    bool flErr = false;
    for (i=1; i<PeakCount; i++)
        if (spec->hArr[i]<0 || spec->mzArr[i] < spec->mzArr[i-1])
        {
            
            cerr << "Error decoding peak " << i << ": mass=" 
                 << spec->mzArr[i] <<  ", intensity=" 
                 << spec->hArr[i] << endl;

            flErr = true;
        }

    if (flErr || spec->mzArr[0]<0 || spec->hArr[0]<0)
    {
        cerr << "Error parsing peaks in mzXML!"<< endl;
        return 1;
    }
*/
    return 0;
}

// Parse an int - skip characters until you see digits or -, then read until you 
// see something else.
int ParseIntFromXML(char* AttributeString)
{
    char Buffer[256];
    int CharCount;
    
    if (!AttributeString || !*AttributeString)
    {
        return 0;
    }
    CharCount = 0;
    while ((*AttributeString < '0' || *AttributeString > '9') && *AttributeString != '-')
    {
        if (!*AttributeString || CharCount > 256)
        {
            return 0; // too much non-digit garbage!
        }
        AttributeString++;
    }
    CharCount = 0;
    while (*AttributeString >= '0' && *AttributeString <= '9')
    {
        Buffer[CharCount++] = *AttributeString;
        if (CharCount > 10)
        {
            break;
        }
        AttributeString++;
    }
    Buffer[CharCount] = '\0';
    return atoi(Buffer);
}

// Parse a float - skip characters until you see digits or -, then read until you 
// see something else.
float ParseFloatFromXML(char* AttributeString)
{
    char Buffer[256];
    int CharCount;
    
    if (!AttributeString || !*AttributeString)
    {
        return 0;
    }
    CharCount = 0;
    while ((*AttributeString < '0' || *AttributeString > '9') && *AttributeString != '-')
    {
        if (!*AttributeString || CharCount > 256)
        {
            return 0; // too much non-digit garbage!
        }
        AttributeString++;
    }
    CharCount = 0;
    while ( (*AttributeString >= '0' && *AttributeString <= '9') || *AttributeString == '.')
    {
        Buffer[CharCount++] = *AttributeString;
        if (CharCount > 10)
        {
            break;
        }
        AttributeString++;
    }
    Buffer[CharCount] = '\0';

    return atof(Buffer);
}

// from PepNovo src/base64.cpp
void b64_decode_mio ( char *dest,  char *src )
{
   char *temp;

  temp = dest;

  while (*src)
    {
      int register a;
      int register b;
      int t1,t2,t3,t4;

      t1 = src[0];
      t2 = src[1];
      t3 = src[2];
      t4 = src[3];

      if (t1 == 61 )        // if == '='
    return;
     
      if( t1 > 96 )        // [a-z]
    a = (t1 - 71);
      else if( t1 > 64 )        // [A-Z]
    a = (t1 - 65);
      else if( t1 > 47 )        // [0-9]
    a = (t1 + 4);
      else if( t1 == 43 )
    a = 62;
      else                // src[0] == '/'
    a = 63;     


      if( t2 > 96 )        // [a-z]
    b = (t2 - 71);
      else if( t2 > 64 )        // [A-Z]
    b = (t2 - 65);
      else if( t2 > 47 )        // [0-9]
    b = (t2 + 4);
      else if( t2 == 43 )
    b = 62;
      else                // src[0] == '/'
    b = 63;     
    
      *temp++ = ( a << 2) | ( b >> 4);
     
      if (t3 == 61)
    return;

      if( t3 > 96 )        // [a-z]
    a = (t3 - 71);
      else if( t3 > 64 )        // [A-Z]
    a = (t3 - 65);
      else if( t3 > 47 )        // [0-9]
    a = (t3 + 4);
      else if( t3 == 43 )
    a = 62;
      else                // src[0] == '/'
    a = 63;     


      *temp++ = ( b << 4) | ( a >> 2);

      if (t4 == 61)
    return;

      if( t4 > 96 )        // [a-z]
    b = (t4 - 71);
      else if( t4 > 64 )        // [A-Z]
    b = (t4 - 65);
      else if( t4 > 47 )        // [0-9]
    b = (t4 + 4);
      else if( t4 == 43 )
    b = 62;
      else                // src[0] == '/'
    b = 63;    

      *temp++ = ( a << 6) | ( b );

      src += 4;
    }
}
