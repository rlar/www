#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <stdlib.h>
#include "mzXMLReader.h"

#define FLDEBUG 1

using namespace std;

int buildScanList( string filename, vector<int> * vecScans );

int main(int argc, char** argv)
{
	int 		err				= 0,
				i				= 0;
	string 		filename 		= "",
				fileScanlist	= "";
	mzXMLreader reader;
	vector<int> vecScans;
	
	
	if (FLDEBUG) cout << "running main..." << endl;
	
	// attempt to open the mzXML file
	if (argc < 3)
	{
        cerr << "Usage: ./parser filename.mzXML scannumlist.txt" << endl;
        return 1;
    }
    
    // store file names for parsing
    filename = argv[1];
    fileScanlist = argv[2];
    
    // build the vector of scans we want to investigate (MS2 spectra)
    if ( buildScanList( fileScanlist, &vecScans) )
    {
		// error reported in buildScanList
		return 1;
	}
	
    
    if (FLDEBUG) cout << "parsing " << filename << "..." << endl;
    
    // parse the mzXML file, printing out the m/z, mean and variance
	reader.parse( filename, &vecScans );

	return 0;
}

int buildScanList( string filename, vector<int> * vecScans )
{
	ifstream inf;
	string line;
	int scanNum;
	
	// try to open the file to build the scan list
	inf.open( filename.c_str(), ifstream::in );
	
	if (!inf)
    {
        cerr << "Error: Couldn't open " << filename << endl;
        return 1;
    }
    
    // build the scan list
    int i = 0;
    while ( inf.good() )
    {
		getline (inf,line);
		scanNum = atoi( line.c_str() );
		
		// add only valid scanNums to the mapping (no failed atoi's)
		if (scanNum > 0) vecScans->push_back( scanNum );
    }
    
    inf.close();
	
	return 0;
}
