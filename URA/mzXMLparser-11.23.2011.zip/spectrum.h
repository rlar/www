#ifndef __SPECTRUM_H__
#define __SPECTRUM_H__

class spectrum
{
	public:
		float 	mz;	// precursor mass
		int 	z;	// charge
		float	rt;	// retention time (minutes)
		
		float mzArr[];
		float hArr[];
		float highestPeak;
};

#endif
