#include "mzXMLReader.h"
#include "base64.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <map>
#include <stdlib.h>
#include "spectrum.h"
#include <vector>

#define FLDEBUG 1

using namespace std;

int getIndexOffset(string filename, int *offset);
int parseIndex(string filename, map<int,int> * mapIndex, int indexOffset);
int loopThruScans(string filename, vector<int> *vecScans, map<int,int> * mapIndex, int indexOffset);

int mzXMLreader::parse(string filename, vector<int> *vecScans)
{
	int nScans = -1,
		offset = -1,
		err = 0;
		
	map<int,int> mapIndex;
	
	if (FLDEBUG) cout << "parsing..." << endl
					  << "parsing index offset..." << endl;
	
	// determine the offset of the index of the file
	if ( getIndexOffset(filename, &offset) )
	{
		// error reported in getIndexOffset
		return 1;
	}
	
	if (FLDEBUG) cout << "index offset is " << offset << endl
					  << "parsing scan offsets from index..." << endl;
	
	// parse the index into an associative map to retrieve scan offsets
	if ( parseIndex(filename, &mapIndex, offset) )
	{
		// error reported in getIndexOffset
		return 2;
	}
	
	if (FLDEBUG) cout << "found offsets for " << mapIndex.size() 
	                  << " scans" << endl;
	
	/// loop through the scans, doing something - have to figure out what this is still...
	if ( loopThruScans(filename, vecScans, &mapIndex, offset) )
	{
		// error reported in loopThruScans
		return 3;
	}
	
	return 0;
}

/// an xml parser is probably ideal for this job, but the following fn
/// should be fine as is. future enhancement - use tinyxml/other library?
int getIndexOffset(string filename, int *offset)
{
	ifstream inf;
    char 	buffer[200];
    string 	line				= "",
			indexOffset			= "<indexOffset>",
			indexOffsetClose	= "</indexOffset>";
	size_t 	found, 
			found2;
			
	// try to open the file to extract the offset of the index block
	inf.open( filename.c_str(), ifstream::in );
	
	if (!inf)
    {
        cerr << "getIndexOffset: couldn't open " << filename << endl;
        return -1;
    }
    
    // move to the end of the file and try to find the index offset
	/* NOTE: tail should resemble 
	    </index>
		<indexOffset>127618357</indexOffset>
		<sha1>d2a04eebb2c0984062eb9ad1dc7d844ac58e2456</sha1>
		</mzXML>
	*/
	
    inf.seekg(-200,ios::end);
    inf.read(buffer, 200);
    line = buffer;
    
    found = line.find(indexOffset);
    
    if (found == string::npos )
    {
        cerr << "getIndexOffset: couldn't find the <index> of " << filename << endl;
        return 1;
	}
	
	// go to the index of the mzXML
	found2 = line.find(indexOffsetClose);
	
	if (found2 == string::npos )
    {
        cerr << "getIndexOffset: couldnt find </indexOffset> tag of " << filename << endl;
        return 1;
	}
	
	// extract and parse the index offset in bytes
	int start = found + indexOffset.size();
	int len = found2 - found + indexOffset.size();
	*offset = atoi( line.substr( start, len ).c_str() );
	        
	inf.close();
	return 0;
    
    /*   the snippet below is so i remember how to do random access reading
    // Get the rest of the line and print it
    getline(inf, line);
    cout << strData << endl;

    inf.seekg(8, ios::cur); // move 8 more bytes into file
    // Get rest of the line and print it
    getline(inf, strData);
    cout << strData << endl;

    inf.seekg(-15, ios::end); // move 15 bytes before end of file
    // Get rest of the line and print it
    getline(inf, strData);
    cout << strData << endl;
    */
}

// parseIndex: map scan # to byte offset into file
int parseIndex(string filename, map<int,int> * mapIndex, int indexOffset)
{
	ifstream inf;
    char 	buffer[256];
    string 	line			= "",
			indexOpen		= "<index name=\"scan\" >",
			offsetIDOpen	= "<offset id=\"",
			offsetIDClose	= "\" >",
			offsetClose		= "</offset>",
			indexClose		= "</index>";
	int		start			= 0,
			len				= 0,
			scan			= 0,
			offset			= 0;
			
	// try to open the file to parse the index
	inf.open( filename.c_str(), ifstream::in );
	
	if (!inf)
    {
        cerr << "parseIndex: couldn't open " << filename << endl;
        return 1;
    }
    
    // move to the start of the index
    inf.seekg(indexOffset,ios::beg);
    inf.getline(buffer,256);
    line = buffer;
    
    if (line.find(indexOpen) == string::npos )
    {
        cerr << "parseIndex: <index> tag malformed or wrong index offset" 
             << endl;
        return 2;
	}
	
	// loop through the index, and parse out each scans offset
	inf.getline(buffer,256);
    line = buffer;
	while ( line.find(indexClose) == string::npos )
	{
		// careful making assumptions about the index string format,
		// catch any errors
		try
		{
			// extract the scan ID
			start = line.find(offsetIDOpen) + offsetIDOpen.size();
			len = line.find(offsetIDClose) - start;
			scan = atoi( line.substr( start, len ).c_str() );
			
			// extract the scans offset
			start = line.find(offsetIDClose) + offsetIDClose.size();
			len = line.find(offsetClose) - start;
			offset = atoi( line.substr( start, len ).c_str() );
			
			// add this scan and offset pair to the map
			mapIndex->insert( pair<int,int>(scan,offset) );
		}
		catch (int e)
		{
			cerr << "Warning: an error occurred when parsing the " 
			     << "following line of the scan/offset index:" << endl
			     << line << endl;
		}
		
		// go to next line
		inf.getline(buffer,256);
		line = buffer;
	}

	// add a "dummy" entry to the end of the map that stores the offset
	// of the index, so that we can still calculate how many bytes to
	// read for the last scan entry
	mapIndex->insert( pair<int,int>(scan+1,indexOffset) );

	inf.close();
	return 0;
}


int loopThruScans(string filename, vector<int> *vecScans, map<int,int> * mapIndex, int indexOffset)
{
	int 	i			= 0,
			scanNum		= 0,
			offset		= 0,
			len			= 0,
			result		= 0;
	FILE 	*pFile		= NULL;
	char 	*buffer		= NULL;
	string 	scanOpen	= "<scan num=\"",
			peaksOpen	= "<peaks ";
			
			
	// open the mzXML file
	pFile = fopen ( filename.c_str() , "r" );
	if ( pFile==NULL )
	{
		cerr << "loopThruScans: couldnt open " << filename << endl;
		return 1; 
	}
			
	// iterate through the vector of scan IDs, performing 
	///some operation on them
	for (i = 0; i < vecScans->size(); i++)
	{
		scanNum = (*vecScans)[i];
		
		// find the how many bytes into the mzXML this scans' data starts,
		// and how long it is ( length = offsetOfNextScan - offsetOfThisScan)
		offset = mapIndex->find( scanNum )->second;
		len = mapIndex->find( scanNum+1 )->second - offset;
		
		// move file pointer to start of scan block
		fseek(pFile, offset, SEEK_SET);
		
		// allocate memory for this block
		buffer = (char*) malloc (sizeof(char)*len);
		
		if (buffer == NULL)
		{
			cerr << "loopThruScans: memory error on scan " << scanNum << endl;
		}

		// copy the block into the buffer
		result = fread (buffer,1,len,pFile);
		if (result != len)
		{
			cerr << "loopThruScans: read error on scan " << scanNum << endl;
		}

		cout << buffer << endl;
		
		free (buffer);
		/*
		/// ////////////////////////////////////////////////////////////
			
			// testing: try to grab the second last scan, print it
			
			len = 127612141 - 127605890;
			
			// move file pointer to start of scan block (i think)
			fseek(pFile, 127605890, SEEK_SET);
			
			// allocate memory to contain the whole block
			buffer = (char*) malloc (sizeof(char)*len);
			  if (buffer == NULL) {fputs ("Memory error",stderr); exit (2);}

			  // copy the block into the buffer:
			  int result = fread (buffer,1,len,pFile);
			  if (result != len) {fputs ("Reading error",stderr); exit (3);}

			  cout << buffer << endl;

			  // terminate
			  free (buff);
			/// ////////////////////////////////////////////////////////////
		*/
	}
	
	fclose (pFile);
	return 0;
}

