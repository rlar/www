#ifndef __MZXMLREADER_H__
#define __MZXMLREADER_H__

#include <string>
#include <vector>

class mzXMLreader{
		public:
			int parse( std::string filename, std::vector<int> *vecScans);
};

#endif
