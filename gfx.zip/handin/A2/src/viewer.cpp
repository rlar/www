#include "viewer.hpp"
#include <iostream>
#include <GL/gl.h>
#include <GL/glu.h>
#include "draw.hpp"
#include "a2.hpp"
#include <sstream>
#include <iomanip>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

Viewer::Viewer()
{
  Glib::RefPtr<Gdk::GL::Config> glconfig;

  // Ask for an OpenGL Setup with
  //  - red, green and blue component colour
  //  - a depth buffer to avoid things overlapping wrongly
  //  - double-buffered rendering to avoid tearing/flickering
  glconfig = Gdk::GL::Config::create(Gdk::GL::MODE_RGB |
                                     Gdk::GL::MODE_DEPTH |
                                     Gdk::GL::MODE_DOUBLE);
  if (glconfig == 0) {
    // If we can't get this configuration, die
    std::cerr << "Unable to setup OpenGL Configuration!" << std::endl;
    abort();
  }

  // Accept the configuration
  set_gl_capability(glconfig);

  // Register the fact that we want to receive these events
  add_events(Gdk::BUTTON1_MOTION_MASK    |
             Gdk::BUTTON2_MOTION_MASK    |
             Gdk::BUTTON3_MOTION_MASK    |
             Gdk::BUTTON_PRESS_MASK      | 
             Gdk::BUTTON_RELEASE_MASK    |
             Gdk::POINTER_MOTION_MASK    |
             Gdk::VISIBILITY_NOTIFY_MASK);

  m_label_mode = NULL;
  m_label_z = NULL;
  
  // initialize object coordinates
  m_init_cube = 
  {
    Point3D(-1.0, 1.0, 1.0),
    Point3D(-1.0, -1.0, 1.0),
    Point3D(1.0, -1.0, 1.0),
    Point3D(1.0, 1.0, 1.0),
    Point3D(-1.0, 1.0, -1.0),
    Point3D(-1.0, -1.0, -1.0),
    Point3D(1.0, -1.0, -1.0),
    Point3D(1.0, 1.0, -1.0)
  };
  
  m_init_modelling_gnomon = 
  {
    Point3D(0.0, 0.0, 0.0),
    Point3D(0.5, 0.0, 0.0),
    Point3D(0.0, 0.5, 0.0),
    Point3D(0.0, 0.0, 0.5)
  };
  
  m_init_world_gnomon = 
  {
    Point3D(0.0, 0.0, 0.0),
    Point3D(0.5, 0.0, 0.0),
    Point3D(0.0, 0.5, 0.0),
    Point3D(0.0, 0.0, 0.5)
  };
  
  m_label_mode = NULL;
  m_label_z = NULL;
  
  // Initialize window edge information
  m_window_edge_normals = 
  {
    Vector3D(0.0,0.0,1.0),
    Vector3D(0.0,-1.0,0.0),  
    Vector3D(1.0,0.0,0.0), 
    Vector3D(0.0,1.0,0.0),   
    Vector3D(-1.0,0.0,0.0),  
    Vector3D(0.0,0.0,-1.0)
  };
  
  m_window_edge_points =
  {
    Point3D(0.0, 0.0, -1.0),
    Point3D(0.0, 1.0, 0.0),
    Point3D(-1.0, 0.0, 0.0),
    Point3D(0.0, -1.0, 0.0),
    Point3D(1.0, 0.0, 0.0),
    Point3D(0.0, 0.0, 1.0)
  };
  
  // Initialize transformation matrices, viewport coordinates, perspective params
  set_view();
}

Viewer::~Viewer()
{
  // Nothing to do here right now.
}

void Viewer::invalidate()
{
  // Force a rerender
  Gtk::Allocation allocation = get_allocation();
  get_window()->invalidate_rect( allocation, false);
}

double Viewer::aspect()
{
  return abs( (m_viewport[1][1] - m_viewport[0][1]) / (m_viewport[1][0] - m_viewport[0][0]) );
}

void Viewer::set_perspective(double fov, double aspect,
                             double near, double far)
{
  // Update perspective parameters
  m_fov = fov;
  m_aspect = aspect;
  m_near = near;
  m_far = far;
  
  if (m_near == m_far)
    m_far = m_near + 0.0000000000000001;
    
  // Update labels
  std::ostringstream s;
  s << "Z Planes: Near = " << std::setw(3) << m_near 
    << ", Far = " << std::setw(3) << m_far;

  if (m_label_z) m_label_z->set_text ( s.str() );
  
  // Update our perspective transformation matrix
  double cot = 1/std::tan( M_PI*fov/360);
  double p[16] = 
  {
    cot/aspect , 0.0,                      0.0,                    0.0,
    0.0,         cot,                      0.0,                    0.0,
    0.0,         0.0,    (far+near)/(far-near), -2*far*near/(far-near),
    0.0,         0.0,                      1.0,                    0.0
  };
  
  m_projection = Matrix4x4( p );
}

void Viewer::set_mode( Viewer::Mode mode )
{
  m_mode = mode;
  
  switch( mode )
  {
    case VIEW_ROTATE:
      m_label_mode->set_text ("Mode: View - Rotate");
      break;
      
    case VIEW_TRANSLATE:
      m_label_mode->set_text ("Mode: View - Translate");
      break;
      
    case PERSPECTIVE:
      m_label_mode->set_text ("Mode: Perspective");
      break;
      
    case MODEL_ROTATE:
      m_label_mode->set_text ("Mode: Model - Rotate");
      break;
      
    case MODEL_TRANSLATE:
      m_label_mode->set_text ("Mode: Model - Translate");
      break;
      
    case MODEL_SCALE:
      m_label_mode->set_text ("Mode: Model - Scale");
      break;
      
    case VIEWPORT:
      m_label_mode->set_text ("Mode: Viewport");
      break;
  }
}

void Viewer::set_labels( Gtk::Label *label_mode, Gtk::Label *label_z )
{
  m_label_mode = label_mode;
  m_label_z = label_z;
}

void Viewer::set_view()
{
  // Set transformations to identities
  for (int i=0; i<3; i++)
  {
    m_model[i] = Matrix4x4();
    m_view[i] = Matrix4x4();
  }
  
  // Scale the cube a bit so it's visible
  m_model[0] = scaling( Vector3D(.3,.3,.3) );
  
  // Set viewport to 90% of window
  m_viewport[0] = Point2D(0.05*get_width(), 0.05*get_height());
  m_viewport[1] = Point2D(0.95*get_width(), 0.95*get_height());
  
  // Use default perspective
  set_perspective( 
    30, 
    aspect(),
    1.0,
    20.0
  );
}

void Viewer::reset_view()
{
  set_view();
  invalidate();
}

void Viewer::on_realize()
{
  // Do some OpenGL setup.
  // First, let the base class do whatever it needs to
  Gtk::GL::DrawingArea::on_realize();
  
  Glib::RefPtr<Gdk::GL::Drawable> gldrawable = get_gl_drawable();
  
  if (!gldrawable)
    return;

  if (!gldrawable->gl_begin(get_gl_context()))
    return;

  gldrawable->gl_end();
}

void Viewer::draw_viewport()
{
  set_colour(Colour(0.0, 0.0, 1.0));
  
  // Top
  draw_line( m_viewport[0], Point2D(m_viewport[1][0], m_viewport[0][1]) );
  
  // Left
  draw_line( m_viewport[0], Point2D(m_viewport[0][0], m_viewport[1][1]) );
  
  // Bottom
  draw_line( m_viewport[1], Point2D(m_viewport[0][0], m_viewport[1][1]) );
  
  // Right
  draw_line( m_viewport[1], Point2D(m_viewport[1][0], m_viewport[0][1]) );
}

void Viewer::apply_transformations()
{
  // Apply model transformations
  // We have to scale, then rotate, then translate
  for (int i=0; i<8; i++){
    for (int j=0; j<3; j++){
      m_curr_cube[i] = m_model[j] * m_curr_cube[i];
    }
  }

  for (int i=0; i<4; i++){
    // don't scale the gnomons
    for (int j=1; j<3; j++){
      m_curr_modelling_gnomon[i] = m_model[j] * m_curr_modelling_gnomon[i];
    }
  }
  
  // Apply view transformations
  for (int i=0; i<8; i++){
    for (int j=1; j<3; j++){
      m_curr_cube[i] = m_view[j] * m_curr_cube[i];
    }
  }

  for (int i=0; i<4; i++){
    for (int j=1; j<3; j++){
      m_curr_modelling_gnomon[i] = m_view[j] * m_curr_modelling_gnomon[i];
      m_curr_world_gnomon[i] = m_view[j] * m_curr_world_gnomon[i];
    }
  }
}

void Viewer::break_objects_into_lines()
{
  // go through each object, specifying each individual
  // line by distinct endpoints, so that they can be safely clipped
  
  m_lines_modelling_gnomon[0] = m_curr_modelling_gnomon[0]; // X
  m_lines_modelling_gnomon[1] = m_curr_modelling_gnomon[1];
  m_lines_modelling_gnomon[2] = m_curr_modelling_gnomon[0]; // Y
  m_lines_modelling_gnomon[3] = m_curr_modelling_gnomon[2];
  m_lines_modelling_gnomon[4] = m_curr_modelling_gnomon[0]; // Z
  m_lines_modelling_gnomon[5] = m_curr_modelling_gnomon[3];

  for (int i=0; i<3; i++)
    m_lines_modelling_gnomon_clipped[i] = false;
  
  m_lines_world_gnomon[0] = m_curr_world_gnomon[0]; // X
  m_lines_world_gnomon[1] = m_curr_world_gnomon[1];
  m_lines_world_gnomon[2] = m_curr_world_gnomon[0]; // Y
  m_lines_world_gnomon[3] = m_curr_world_gnomon[2];
  m_lines_world_gnomon[4] = m_curr_world_gnomon[0]; // Z
  m_lines_world_gnomon[5] = m_curr_world_gnomon[3];
  
  for (int i=0; i<3; i++)
    m_lines_world_gnomon_clipped[i] = false;

  // front 
  m_lines_cube[0] = m_curr_cube[0]; // top
  m_lines_cube[1] = m_curr_cube[3];
  m_lines_cube[2] = m_curr_cube[0]; // left
  m_lines_cube[3] = m_curr_cube[1];
  m_lines_cube[4] = m_curr_cube[1]; // bottom
  m_lines_cube[5] = m_curr_cube[2];
  m_lines_cube[6] = m_curr_cube[2]; // right
  m_lines_cube[7] = m_curr_cube[3];
  
  // sides
  m_lines_cube[8] = m_curr_cube[0]; // top-left
  m_lines_cube[9] = m_curr_cube[4];
  m_lines_cube[10] = m_curr_cube[1]; // bottom-left
  m_lines_cube[11] = m_curr_cube[5];
  m_lines_cube[12] = m_curr_cube[2]; // bottom-right
  m_lines_cube[13] = m_curr_cube[6];
  m_lines_cube[14] = m_curr_cube[3]; // top-right
  m_lines_cube[15] = m_curr_cube[7];
  
  // back
  m_lines_cube[16] = m_curr_cube[4]; // top
  m_lines_cube[17] = m_curr_cube[7];
  m_lines_cube[18] = m_curr_cube[4]; // left
  m_lines_cube[19] = m_curr_cube[5];
  m_lines_cube[20] = m_curr_cube[5]; // bottom
  m_lines_cube[21] = m_curr_cube[6];
  m_lines_cube[22] = m_curr_cube[6]; // right
  m_lines_cube[23] = m_curr_cube[7];

  for (int i=0; i<12; i++)
    m_lines_cube_clipped[i] = false;
  
}

void Viewer::clip_line_to_edge( Point3D *A, Point3D *B, bool *arrClipped, int idx, int edgeIdx )
{
  // Check if both endpoints are outside
  double lOfA = 
    Vector3D( 
      (*A)[0] - m_window_edge_points[edgeIdx][0],
      (*A)[1] - m_window_edge_points[edgeIdx][1],
      (*A)[2] - m_window_edge_points[edgeIdx][2]
    ).dot( m_window_edge_normals[edgeIdx] );
    
  double lOfB = 
    Vector3D( 
      (*B)[0] - m_window_edge_points[edgeIdx][0],
      (*B)[1] - m_window_edge_points[edgeIdx][1],
      (*B)[2] - m_window_edge_points[edgeIdx][2]
    ).dot( m_window_edge_normals[edgeIdx] );
    
  if (lOfA < 0 && lOfB < 0)
  {
    // this line is completely outside the window edge, clip it
    arrClipped[idx] = true;
  }
  else if (lOfA > 0 && lOfB > 0)
  {
    // this line is completely inside the window edge, leave it
  }
  else
  {
    // this line crosses the window edge. we have to replace the
    // outer endpoint with one on the window edge
    
    double t = lOfA / (lOfA - lOfB);
    
    if (lOfA < 0)
    { // A is outside
      *A = *A + t*Vector3D( (*B)[0]-(*A)[0], (*B)[1]-(*A)[1], (*B)[2]-(*A)[2] );
    }
    else if ( lOfB < 0)
    { // B is outside
      *B = *A + t*Vector3D( (*B)[0]-(*A)[0], (*B)[1]-(*A)[1], (*B)[2]-(*A)[2] );
    }
    else
    { /* points must have been on boundaries, leave them*/ }
  } 
}

void Viewer::clip_line( Point3D *A, Point3D *B, bool *arrClipped, int idx )
{
  // iterate through each window edge, clipping the line AB
  // note that we skip the front and back window edge, since we clip them
  // before projection
  for( int i=1; i<5; i++)
  {
    clip_line_to_edge( A, B, arrClipped, idx, i );     
  }
}

void Viewer::clip_objects( bool frontBackOnly )
{
  if (frontBackOnly)
  {
    // go through each object, clipping each line therein
    for ( int i=0; i<23; i+=2)
    {
      clip_line_to_edge( &m_lines_cube[i], &m_lines_cube[i+1], 
                 (bool *) m_lines_cube_clipped, (int) i/2, 0 );
      clip_line_to_edge( &m_lines_cube[i], &m_lines_cube[i+1], 
                 (bool *) m_lines_cube_clipped, (int) i/2, 5 );
    }
    
    for ( int i=0; i<5; i+=2)
    {
      clip_line_to_edge( &m_lines_modelling_gnomon[i], &m_lines_modelling_gnomon[i+1], 
                 (bool *) m_lines_modelling_gnomon_clipped, (int) i/2, 0 );
      clip_line_to_edge( &m_lines_modelling_gnomon[i], &m_lines_modelling_gnomon[i+1], 
                 (bool *) m_lines_modelling_gnomon_clipped, (int) i/2, 5 );
                 
      clip_line_to_edge( &m_lines_world_gnomon[i], &m_lines_world_gnomon[i+1], 
                 (bool *) m_lines_world_gnomon_clipped, (int) i/2, 0 );
      clip_line_to_edge( &m_lines_world_gnomon[i], &m_lines_world_gnomon[i+1], 
                 (bool *) m_lines_world_gnomon_clipped, (int) i/2, 5 );
    }
  }
  else
  {
    // go through each object, clipping each line therein
    for ( int i=0; i<23; i+=2)
    {
      clip_line( &m_lines_cube[i], &m_lines_cube[i+1], 
                 (bool *) m_lines_cube_clipped, (int) i/2 );
    }
    
    for ( int i=0; i<5; i+=2)
    {
      clip_line( &m_lines_modelling_gnomon[i], &m_lines_modelling_gnomon[i+1], 
                 (bool *) m_lines_modelling_gnomon_clipped, (int) i/2 );
                 
      clip_line( &m_lines_world_gnomon[i], &m_lines_world_gnomon[i+1], 
                 (bool *) m_lines_world_gnomon_clipped, (int) i/2 );
    }
  }
}

Point3D Viewer::convert_NDC_to_viewport( Point3D p, double width, double height )
{
  double xOffset = ( m_viewport[0][0] < m_viewport[1][0]) ? m_viewport[0][0] : m_viewport[1][0];
  double yOffset = ( m_viewport[1][1] > m_viewport[0][1]) ? m_viewport[1][1] : m_viewport[0][1];
  
  // x and y coords start in [-1,1]  (disregard z)

  // Convert to in [0,1]
  p[0] = ( (-1*p[0]) +1)/2;
  p[1] = ( (-1*p[1]) +1)/2;
  
  // Expand to full viewport, inverting y (top left origin on screen)
  // and translate to fit into the viewport
  p[0] = p[0]*width + xOffset;
  p[1] = -1*p[1]*height + yOffset;

  return p;
}

void Viewer::map_object_NDC_to_viewport()
{
  double width = abs( m_viewport[1][0] - m_viewport[0][0] );
  double height = abs( m_viewport[1][1] - m_viewport[0][1] );
  
  // loop through each object's lines, converting
  int i=0;
  
  // gnomons
  for ( i=0; i<6; i++ ){
    m_lines_modelling_gnomon[i] = 
      convert_NDC_to_viewport( m_lines_modelling_gnomon[i], width, height );
  }
  for ( i=0; i<6; i++ ){
    m_lines_world_gnomon[i] = 
      convert_NDC_to_viewport( m_lines_world_gnomon[i], width, height );
  }
  
  // cube
  for ( i=0; i<24; i++ ){
    m_lines_cube[i] = 
      convert_NDC_to_viewport( m_lines_cube[i], width, height );
  }
}

void Viewer::project_objects()
{
  for (int i=0; i<24; i++){
    m_lines_cube[i] = m_projection * m_lines_cube[i];
    
    for (int j=0; j<3; j++)
      if (m_lines_cube[i][2] != 0) m_lines_cube[i][j] /= m_lines_cube[i][2];
  }
  for (int i=0; i<6; i++){
    m_lines_modelling_gnomon[i] = m_projection * m_lines_modelling_gnomon[i];
    m_lines_world_gnomon[i] = m_projection * m_lines_world_gnomon[i];
    
    for (int j=0; j<3; j++)
      if (m_lines_modelling_gnomon[i][2] != 0) m_lines_modelling_gnomon[i][j] /= m_lines_modelling_gnomon[i][2];
    for (int j=0; j<3; j++)
      if (m_lines_world_gnomon[i][2] != 0) m_lines_world_gnomon[i][j] /= m_lines_world_gnomon[i][2];
  }
}

void Viewer::draw_objects()
{
  // go through each of the object's "lines" arrays, drawing
  // the clipped lines to the screen

  // gnomon X
  set_colour(Colour(1.0, 0.0, 0.0));
  if (!m_lines_modelling_gnomon_clipped[0])
    draw_line( Point2D( m_lines_modelling_gnomon[0][0], 
                        m_lines_modelling_gnomon[0][1]),
               Point2D( m_lines_modelling_gnomon[1][0], 
                        m_lines_modelling_gnomon[1][1])
             );
           
  set_colour(Colour(1.0, 0.7, 0.7));
  if (!m_lines_world_gnomon_clipped[0])
    draw_line( Point2D( m_lines_world_gnomon[0][0], 
                        m_lines_world_gnomon[0][1]),
               Point2D( m_lines_world_gnomon[1][0], 
                        m_lines_world_gnomon[1][1])
             );
           
  // gnomon Y
  set_colour(Colour(0.0, 1.0, 0.0));
  if (!m_lines_modelling_gnomon_clipped[1])
    draw_line( Point2D( m_lines_modelling_gnomon[2][0], 
                        m_lines_modelling_gnomon[2][1]),
               Point2D( m_lines_modelling_gnomon[3][0], 
                        m_lines_modelling_gnomon[3][1])
             );
           
  set_colour(Colour(0.7, 1.0, 0.7));
  if (!m_lines_world_gnomon_clipped[1])
    draw_line( Point2D( m_lines_world_gnomon[2][0], 
                        m_lines_world_gnomon[2][1]),
               Point2D( m_lines_world_gnomon[3][0], 
                        m_lines_world_gnomon[3][1])
             );
           
  // gnomon Z
  set_colour(Colour(0.0, 0.0, 1.0));
  if (!m_lines_modelling_gnomon_clipped[2])
    draw_line( Point2D( m_lines_modelling_gnomon[4][0], 
                        m_lines_modelling_gnomon[4][1]),
               Point2D( m_lines_modelling_gnomon[5][0], 
                        m_lines_modelling_gnomon[5][1])
             );
     
  set_colour(Colour(0.7, 0.7, 1.0));
  if (!m_lines_world_gnomon_clipped[2])
    draw_line( Point2D( m_lines_world_gnomon[4][0], 
                        m_lines_world_gnomon[4][1]),
               Point2D( m_lines_world_gnomon[5][0], 
                        m_lines_world_gnomon[5][1])
             );
  
  // cube
  set_colour(Colour(1.0, 1.0, 1.0));
  for ( int i=0; i<23; i+=2)
  {
    if (!m_lines_cube_clipped[ (int) (i/2) ])
      draw_line( Point2D( m_lines_cube[i][0], 
                          m_lines_cube[i][1]),
                 Point2D( m_lines_cube[i+1][0], 
                          m_lines_cube[i+1][1])
               );
  }
}

bool Viewer::on_expose_event(GdkEventExpose* event)
{
  event = NULL; // suppress warning
  Glib::RefPtr<Gdk::GL::Drawable> gldrawable = get_gl_drawable();

  if (!gldrawable) return false;

  if (!gldrawable->gl_begin(get_gl_context()))
    return false;

  // Initialize the current scene objects
  memcpy( m_curr_cube, m_init_cube, 8*sizeof(Point3D));
  memcpy( m_curr_modelling_gnomon, m_init_modelling_gnomon, 4*sizeof(Point3D));
  memcpy( m_curr_world_gnomon, m_init_world_gnomon, 4*sizeof(Point3D));

  // Apply the current transformations
  apply_transformations();

  // Break up each object into its composite lines for clipping
  break_objects_into_lines();
  
  // Clip to the near plane before projection
  clip_objects( true );

  // Project the objects (3D onto 2D in [-1,1])
  project_objects();
  
  // Finish clipping
  clip_objects( false );

  // Map the projected 2D coordinates into our viewport (origin in top left)
  map_object_NDC_to_viewport();
  
  // Draw the current scene
  draw_init(get_width(), get_height());
  
  draw_viewport();
  draw_objects();
  
  draw_complete();
            
  // Swap the contents of the front and back buffers so we see what we
  // just drew. This should only be done if double buffering is enabled.
  gldrawable->swap_buffers();

  gldrawable->gl_end();

  return true;
}

bool Viewer::on_configure_event(GdkEventConfigure* event)
{
  event = NULL; // suppress warning
  Glib::RefPtr<Gdk::GL::Drawable> gldrawable = get_gl_drawable();

  if (!gldrawable) return false;
  
  if (!gldrawable->gl_begin(get_gl_context()))
    return false;

  gldrawable->gl_end();
  
  /// TODO: scale viewport with window. maybe track prev width and height?
  
  invalidate();

  return true;
}

bool Viewer::on_button_press_event(GdkEventButton* event)
{
  // Store this cursor location as previous
  prevCursor.set( event->x, event->time );
  
  if ( m_mode == VIEWPORT && (event->button == 1) )
  {
    // Get the new viewport coordinates (making sure we have nonzero area)
    int x = (event->x == get_width()) ? event->x - 1 : event->x;
    int y = (event->y == get_width()) ? event->y - 1 : event->y;
    
    m_viewport[0][0] = x;
    m_viewport[0][1] = y;
    m_viewport[1][0] = x+1;
    m_viewport[1][1] = y+1;
    
    set_perspective(m_fov, aspect(), m_near, m_far);
    invalidate();
  }
  
  return true;
}

bool Viewer::on_button_release_event(GdkEventButton* event)
{
  invalidate();
  
  // Invalidate the previous cursor location
  prevCursor.invalidate();
  return true;
}

bool Viewer::on_motion_notify_event(GdkEventMotion* event)
{
  double dX, dT;
  
  // Track cursor position if a mouse is pressed
  if (event->state & (GDK_BUTTON1_MASK | GDK_BUTTON2_MASK | GDK_BUTTON3_MASK))
  {
    if ( !prevCursor.valid )
    {
      // We don't have enough information yet to scale or rotate, exit
      prevCursor.set(event->x, event->time);
      return true;
    }
    
    // Get scale/rotation parameters
    dT = event->time - prevCursor.time;
    dX = event->x - prevCursor.x;
    if (dT > 0) dX /= dT;
    
    // Update prevCursor
    prevCursor.set(event->x, event->time);
  
    // Transform the appropriate matrix accordingly
    Vector3D t;
    Matrix4x4 newT;
    switch ( m_mode )
    {
      case VIEW_ROTATE:
        // to rotate wrt the views current rotation, we take the
        // inverse rotation, apply new rotation, and re-rotate
        if (event->state & GDK_BUTTON1_MASK)
          m_view[1] = m_view[1] * rotation(dX/5, 'x') * m_view[1].invert() * m_view[1];
          
        if (event->state & GDK_BUTTON2_MASK)
          m_view[1] = m_view[1] * rotation(dX/5, 'y') * m_view[1].invert() * m_view[1];
          
        if (event->state & GDK_BUTTON3_MASK)
          m_view[1] = m_view[1] * rotation(dX/5, 'z') * m_view[1].invert() * m_view[1];
        break;
          
      case VIEW_TRANSLATE:
        if (event->state & GDK_BUTTON1_MASK)
          t[0] = dX/40;
          
        if (event->state & GDK_BUTTON2_MASK)
          t[1] = dX/40;
          
        if (event->state & GDK_BUTTON3_MASK)
          t[2] = dX/40;
          
        m_view[2] = m_view[1] * translation(t) * m_view[1].invert() * m_view[2];
        break;
        
      case PERSPECTIVE:
      
        if (event->state & GDK_BUTTON1_MASK)
        {
          // Change FOV over the range of 5 to 160 degrees
          if (-1 <= dX && dX <= 1) dX *= 10;
          m_fov += dX;
          
          if (m_fov < 5)
            m_fov = 5;
          else if (m_fov > 160)
            m_fov = 160;
          
          set_perspective( m_fov, m_aspect, m_near, m_far );
        }
          
        if (event->state & GDK_BUTTON2_MASK)
        {
          // Translate the near plane along z
          m_near += dX;
          
          if (m_near < 0)
            m_near = 0;
          else if (m_near > m_far)
            m_near = m_far;
          
          set_perspective( m_fov, m_aspect, m_near, m_far );
        }
          
        if (event->state & GDK_BUTTON3_MASK)
        {
          // Translate the far plane along z
          m_far += dX;
          
          if (m_far < m_near)
            m_far = m_near;
          else if (m_far > 1000)
            m_far = 1000;
          
          set_perspective( m_fov, m_aspect, m_near, m_far );
        }
        break;
        
      case MODEL_ROTATE:
        // to rotate wrt the models current rotation, we take the
        // inverse rotation, apply new rotation, and re-rotate
        if (event->state & GDK_BUTTON1_MASK)
          m_model[1] = m_model[1] * rotation(dX/5, 'x') * m_model[1].invert() * m_model[1];
          
        if (event->state & GDK_BUTTON2_MASK)
          m_model[1] = m_model[1] * rotation(dX/5, 'y') * m_model[1].invert() * m_model[1];
          
        if (event->state & GDK_BUTTON3_MASK)
          m_model[1] = m_model[1] * rotation(dX/5, 'z') * m_model[1].invert() * m_model[1];
        break;
        
      case MODEL_TRANSLATE:
        if (event->state & GDK_BUTTON1_MASK)
          t[0] = dX/20;
          
        if (event->state & GDK_BUTTON2_MASK)
          t[1] = dX/20;
          
        if (event->state & GDK_BUTTON3_MASK)
          t[2] = dX/20;
          
        // to translate wrt the models current rotation, we take the
        // inverse rotation, translate, and re-rotate
        m_model[2] = m_model[1] * translation(t) * m_model[1].invert() * m_model[2];
        break;
        
      case MODEL_SCALE:
        if (event->state & GDK_BUTTON1_MASK)
          m_model[0][0][0] += dX/10;
          
        if (event->state & GDK_BUTTON2_MASK)
          m_model[0][1][1] += dX/10;
          
        if (event->state & GDK_BUTTON3_MASK)
          m_model[0][2][2] += dX/10;

        // Limit scaling reasonably
        // X
        if ( m_model[0][0][0] < .1 )
          m_model[0][0][0] = .1;
        else if (m_model[0][0][0] > 2 )
          m_model[0][0][0] = 2;
        // Y
        if ( m_model[0][1][1] < .1 )
          m_model[0][1][1] = .1;
        else if (m_model[0][1][1] > 2 )
          m_model[0][1][1] = 2;
        // Z
        if ( m_model[0][2][2] < .1 )
          m_model[0][2][2] = .1;
        else if (m_model[0][2][2] > 2 )
          m_model[0][2][2] = 2;
        break;
        
      case VIEWPORT:
        if ( event->state & GDK_BUTTON1_MASK )
        {
          // Get the new viewport coordinate (making sure we have nonzero area)
          int x = (event->x >= get_width()) ? get_width() - 1 : event->x;
          int y = (event->y >= get_height()) ? get_height() - 1 : event->y;
          
          if (x < 0) x = 0;
          if (y < 0) y = 0;
          
          m_viewport[1][0] = x;
          m_viewport[1][1] = y;
          set_perspective(m_fov, aspect(), m_near, m_far);
          invalidate();
        }
        break;
    }
    
    // re-render game window
    invalidate();
  }
  return true;
}

