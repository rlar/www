#include "a2.hpp"

// Return a matrix to represent a counterclockwise rotation of "angle"
// degrees around the axis "axis", where "axis" is one of the
// characters 'x', 'y', or 'z'.
Matrix4x4 rotation(double angle, char axis)
{
    double newRotation[16];
    double sinA = std::sin(angle);
    double cosA = std::cos(angle);
    
    if (axis == 'x')
    {
      newRotation = 
        {
          1.0,     0.0,     0.0,       0.0,
          0.0,     cosA,    -1*sinA,   0.0,
          0.0,     sinA,    cosA,      0.0,
          0.0,     0.0,     0.0,       1.0
        };
    }
    else if (axis == 'y')
    {
      newRotation = 
        {
          cosA,    0.0,     sinA,      0.0,
          0.0,     1.0,     0.0,       0.0,
          -1*sinA, 0.0,     cosA,      0.0,
          0.0,     0.0,     0.0,       1.0
        };
    }
    else if (axis == 'z')
    {
      newRotation = 
        {
          cosA,    -1*sinA, 0.0,       0.0,
          sinA,    cosA,    0.0,       0.0,
          0.0,     0.0,     1.0,       0.0,
          0.0,     0.0,     0.0,       1.0
        };
    }
    else
    {
      std::cerr << "Error: rotation() called with unknown axis " << axis << "!" << std::endl;
    }
    
    return Matrix4x4( newRotation );
}

// Return a matrix to represent a displacement of the given vector.
Matrix4x4 translation(const Vector3D& displacement)
{
  double t[16]= 
    {
      1.0,     0.0,     0.0,       displacement[0],
      0.0,     1.0,     0.0,       displacement[1],
      0.0,     0.0,     1.0,       displacement[2],
      0.0,     0.0,     0.0,       1.0
    };
    
  return Matrix4x4( t );
}

// Return a matrix to represent a nonuniform scale with the given factors.
Matrix4x4 scaling(const Vector3D& scale)
{
  double s[16]= 
    {
      scale[0], 0.0,      0.0,       0.0,
      0.0,      scale[1], 0.0,       0.0,
      0.0,      0.0,      scale[2],  0.0,
      0.0,      0.0,      0.0,       1.0
    };
    
  return Matrix4x4( s );
}
