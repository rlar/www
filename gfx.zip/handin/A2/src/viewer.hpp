#ifndef CS488_VIEWER_HPP
#define CS488_VIEWER_HPP

#include <gtkmm.h>
#include <gtkglmm.h>
#include "algebra.hpp"

// The "main" OpenGL widget
class Viewer : public Gtk::GL::DrawingArea {
public:
  Viewer();
  virtual ~Viewer();

  // A useful function that forces this widget to rerender. If you
  // want to render a new frame, do not call on_expose_event
  // directly. Instead call this, which will cause an on_expose_event
  // call when the time is right.
  void invalidate();

  // *** Fill in these functions (in viewer.cpp) ***

  // Set the parameters of the current perspective projection using
  // the semantics of gluPerspective().
  void set_perspective(double fov, double aspect,
                       double near, double far);

  // Set or restore all the transforms and perspective parameters to their
  // original state. Set the viewport to its initial size.
  void set_view();
  void reset_view();
  
  enum Mode {
    VIEW_ROTATE = 0,
    VIEW_TRANSLATE,
    
    PERSPECTIVE,
    
    MODEL_ROTATE,
    MODEL_TRANSLATE,
    MODEL_SCALE,
    
    VIEWPORT
  };
  
  void set_mode( Viewer::Mode mode );
  void set_labels( Gtk::Label *label_mode, Gtk::Label *label_z );

protected:

  // Events we implement
  // Note that we could use gtkmm's "signals and slots" mechanism
  // instead, but for many classes there's a convenient member
  // function one just needs to define that'll be called with the
  // event.

  // Called when GL is first initialized
  virtual void on_realize();
  // Called when our window needs to be redrawn
  virtual bool on_expose_event(GdkEventExpose* event);
  // Called when the window is resized
  virtual bool on_configure_event(GdkEventConfigure* event);
  // Called when a mouse button is pressed
  virtual bool on_button_press_event(GdkEventButton* event);
  // Called when a mouse button is released
  virtual bool on_button_release_event(GdkEventButton* event);
  // Called when the mouse moves
  virtual bool on_motion_notify_event(GdkEventMotion* event);
  
  // Drawing functions and helpers
  void break_objects_into_lines();
  
  void clip_line_to_edge( Point3D *A, Point3D *B, bool *arrClipped, int idx, int edgeIdx );
  void clip_line( Point3D *A, Point3D *B, bool *arrClipped, int idx );
  void clip_objects( bool frontOnly);
  
  Point3D convert_NDC_to_viewport( Point3D p, double width, double height );
  void map_object_NDC_to_viewport();
  
  void project_objects();
  
  void draw_viewport();
  void draw_objects();
  void apply_transformations();
  
  double aspect();

private:

  // A reference to the labels so we can update them when params change
  Gtk::Label *m_label_mode, *m_label_z;
  
  Mode m_mode;

  // The 3D->2D projection transform matrix
  Matrix4x4 m_projection;
  
  // Store the transformations for each object
  // One matrix each for scaling, rotation, and translation
  Matrix4x4 m_model[3];
  Matrix4x4 m_view[3];
  
  // Store the perspective parameters
  double m_fov, m_aspect, m_near, m_far;
  
  // Store the top-left and bottom-right coordinates of the viewport
  Point2D m_viewport[2];
  
  // Store the cube's coordinates (CCW from top-left; front face then back)
  // Two versions - initial (coords at (+-1, +-1, +-1) )
  //                current (after transformations have been applied)
  Point3D m_init_cube[8];
  Point3D m_curr_cube[8];
  
  // Store the initial and transformed gnomons (O, x, y, z point coords)
  Point3D m_init_modelling_gnomon[4];
  Point3D m_curr_modelling_gnomon[4];
  Point3D m_init_world_gnomon[4];
  Point3D m_curr_world_gnomon[4];
  
  // Store each object as its composite lines, for clipping
  // The companion bool array indicates if this line was completely clipped
  //
  // cube: 12 lines x 2 endpoints 
  //   front: top, left, bottom, right 
  //   sides: top-left, bottom-left, bottom-right, top-right 
  //   back:  top, left, bottom, right 
  Point3D m_lines_cube[24];
  bool m_lines_cube_clipped[12];
  
  // gnomons: 3 lines x 2 endpoints (O-x line, O-y line, O-z line)
  Point3D m_lines_modelling_gnomon[6];
  bool m_lines_modelling_gnomon_clipped[3];
  
  Point3D m_lines_world_gnomon[6];
  bool m_lines_world_gnomon_clipped[3];
  
  // Window edge normals and points for clipping
  // front, top, left, bottom, right, back
  Vector3D m_window_edge_normals[6];
  Point3D m_window_edge_points[6];
  
  // Cursor tracking for applying transformations
  // Stores information about the last cursor location while
  // a mouse button was held down
  struct PrevCursor {
      int x;
      int prevX;
      int time;
      bool valid;
      
      PrevCursor(){
        invalidate();
      }
      
      void invalidate(){
        x = -1;
        prevX = -1;
        time = -1;
        valid = false;
      }
      void  set( int in_x, int in_time ){
        prevX = x;
        x = in_x;
        time = in_time;
        valid = (prevX >= 0);
      }
    } prevCursor;
};

#endif

