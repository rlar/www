#include "appwindow.hpp"

AppWindow::AppWindow()
{
  set_title("CS488 Assignment Two");

  // A utility class for constructing things that go into menus, which
  // we'll set up next.
  using Gtk::Menu_Helpers::MenuElem;
  using Gtk::Menu_Helpers::RadioMenuElem;
  
  // Set up the application menu
  m_menu_app.items().push_back(MenuElem("Reset (_a)", Gtk::AccelKey("a"),
    sigc::mem_fun(*this, &AppWindow::reset)));
  m_menu_app.items().push_back(MenuElem("_Quit", Gtk::AccelKey("q"),
    sigc::mem_fun(*this, &AppWindow::hide)));
    
  // Set up the mode menu
  Gtk::RadioButton::Group gr_mode;
  
  sigc::slot1<void, Viewer::Mode> mode_slot = 
  	sigc::mem_fun(m_viewer, &Viewer::set_mode);
    
  m_menu_mode.items().push_back(RadioMenuElem( gr_mode, "View - R_otate",
    Gtk::AccelKey("o"), sigc::bind( mode_slot, Viewer::VIEW_ROTATE )));
  m_menu_mode.items().push_back(RadioMenuElem( gr_mode, "View - Tra_nslate",
    Gtk::AccelKey("n"), sigc::bind( mode_slot, Viewer::VIEW_TRANSLATE )));
    
  m_menu_mode.items().push_back(RadioMenuElem( gr_mode, "_Perspective",
    Gtk::AccelKey("p"), sigc::bind( mode_slot, Viewer::PERSPECTIVE )));
    
  m_menu_mode.items().push_back(RadioMenuElem( gr_mode, "Model - _Rotate",
    Gtk::AccelKey("r"), sigc::bind( mode_slot, Viewer::MODEL_ROTATE )));
  m_menu_mode.items().push_back(RadioMenuElem( gr_mode, "Model - _Translate",
    Gtk::AccelKey("t"), sigc::bind( mode_slot, Viewer::MODEL_TRANSLATE )));
  m_menu_mode.items().push_back(RadioMenuElem( gr_mode, "Model - _Scale",
    Gtk::AccelKey("s"), sigc::bind( mode_slot, Viewer::MODEL_SCALE )));
    
  m_menu_mode.items().push_back(RadioMenuElem( gr_mode, "_Viewport",
    Gtk::AccelKey("v"), sigc::bind( mode_slot, Viewer::VIEWPORT )));

  m_label_mode.set_text ("Mode: View - Rotate");
  m_label_z.set_text ("Z Planes: Near = 1.0, Far = 10.0");

  // Pack in our widgets
  m_menubar.items().push_back(Gtk::Menu_Helpers::MenuElem("Application", m_menu_app));
  m_menubar.items().push_back(Gtk::Menu_Helpers::MenuElem("Mode", m_menu_mode));
  
  // First add the vertical box as our single "top" widget
  add(m_vbox);

  // Put the menubar on the top, and make it as small as possible
  m_vbox.pack_start(m_menubar, Gtk::PACK_SHRINK);
  
  // Add the info labels to the window
  m_vbox.pack_start(m_label_mode, Gtk::PACK_SHRINK);
  m_vbox.pack_start(m_label_z, Gtk::PACK_SHRINK);
  

  // Put the viewer below the menubar. pack_start "grows" the widget
  // by default, so it'll take up the rest of the window.
  m_viewer.set_size_request(300, 300);
  m_vbox.pack_start(m_viewer);

  show_all();
  
  // Set up the Viewer with the current size and provide the labels
  m_viewer.set_labels( &m_label_mode, &m_label_z );
  m_viewer.reset_view();
}

void AppWindow::reset()
{
  m_viewer.reset_view();
}
