#include "viewer.hpp"
#include <iostream>
#include <GL/gl.h>
#include <GL/glu.h>

#ifndef DEBUG
  #define DEBUG 1
#endif
const int Viewer::speedTicksMS[3] = { 750, 550, 300 };

Viewer::Viewer()
{
  Glib::RefPtr<Gdk::GL::Config> glconfig;

  // Ask for an OpenGL Setup with
  //  - red, green and blue component colour
  //  - a depth buffer to avoid things overlapping wrongly
  //  - double-buffered rendering to avoid tearing/flickering
  glconfig = Gdk::GL::Config::create(Gdk::GL::MODE_RGB |
                                     Gdk::GL::MODE_DEPTH |
                                     Gdk::GL::MODE_DOUBLE);
  if (glconfig == 0) {
    // If we can't get this configuration, die
    std::cerr << "Unable to setup OpenGL Configuration!" << std::endl;
    abort();
  }

  // Accept the configuration
  set_gl_capability(glconfig);

  // Register the fact that we wanqt to receive these events
  add_events(Gdk::BUTTON1_MOTION_MASK    |
             Gdk::BUTTON2_MOTION_MASK    |
             Gdk::BUTTON3_MOTION_MASK    |
             Gdk::BUTTON_PRESS_MASK      | 
             Gdk::BUTTON_RELEASE_MASK    |
             Gdk::POINTER_MOTION_MASK    |
             Gdk::VISIBILITY_NOTIFY_MASK);

  // Set the initial rotation and scale parameters 
  scaleParams = { 1.0, 1.0, 1.0 };
  rotationMatrix = new Matrix4x4(); // (Identity)
  prevRotation = new Matrix4x4(); // (Identity)
  
  // Initialize modes
  bufferMode = DOUBLE;
  drawMode = FACE;
  speedMode = SLOW;
  
  // Load the default tick times per speed into the current
  memcpy( currentSpeedTicksMS, speedTicksMS, 3*sizeof(int) );
  
  rowsCompletedSinceSpeedup = 0;
  tLastMouseRelease = 0;
  
  // Load the game
  game = new Game(game_width,game_height);
  
  // Assign the colours to draw each piece with
  pieceColourRGB[0] = { 0.568627451, 0.17254902, 0.933333333 }; // purple
  pieceColourRGB[1] = { 1.0,         0.54901961, 0.0         }; // orange
  pieceColourRGB[2] = { 0.388235294, 0.72156863, 1.0         }; // steelblue 1
  pieceColourRGB[3] = { 0.0,         0.0,        1.0         }; // blue
  pieceColourRGB[4] = { 1.0,         0.0,        0.0         }; // red
  pieceColourRGB[5] = { 1.0,         0.07843137, 0.576470588 }; // deep pink
  pieceColourRGB[6] = { 0.4,         0.80392157, 0.666666667 }; // medium aquamarine
  
  // Attach the game timer
  tickConnection = Glib::signal_timeout().connect(
    sigc::mem_fun(*this, &Viewer::tick), currentSpeedTicksMS[speedMode]);
    
  // Attach an invalidate() timer to keep the screen refreshing during persistence
  Glib::signal_timeout().connect(
    sigc::mem_fun(*this, &Viewer::invalidate), 14);
}

Viewer::~Viewer()
{
  delete rotationMatrix;
}

bool Viewer::invalidate()
{
  //Force a rerender
  Gtk::Allocation allocation = get_allocation();
  get_window()->invalidate_rect( allocation, false);
  return true;
}

void Viewer::on_realize()
{
  // Do some OpenGL setup.
  // First, let the base class do whatever it needs to
  Gtk::GL::DrawingArea::on_realize();
  
  Glib::RefPtr<Gdk::GL::Drawable> gldrawable = get_gl_drawable();
  
  if (!gldrawable)
    return;

  if (!gldrawable->gl_begin(get_gl_context()))
    return;

  // Just enable depth testing and set the background colour.
  glEnable(GL_DEPTH_TEST);
  glClearColor(0.7, 0.7, 1.0, 0.0);

  gldrawable->gl_end();
}

void Viewer::reset_game()
{
  // Reset the game
  game->reset();
  rowsCompletedSinceSpeedup = 0;
  
  
  // Reset the game tick timer
  memcpy( currentSpeedTicksMS, speedTicksMS, 3*sizeof(int) );
  
  if ( tickConnection.connected() ) 
    tickConnection.disconnect();
    
  tickConnection = Glib::signal_timeout().connect(
    sigc::mem_fun(*this, &Viewer::tick), currentSpeedTicksMS[speedMode]);
  
  invalidate();
}

void Viewer::reset_view()
{
  scaleParams = { 1.0, 1.0, 1.0 };
  delete rotationMatrix;
  rotationMatrix = new Matrix4x4(); // (Identity)
  delete prevRotation;
  prevRotation = new Matrix4x4(); // (Identity)
  invalidate();
}

void Viewer::set_draw_mode( Viewer::DrawMode mode )
{
  drawMode = mode;
  switch( drawMode )
  {
    case WIREFRAME:
      glPolygonMode( GL_FRONT_AND_BACK, GL_LINE );
      break;
    
    case FACE:
      glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );
      break;
      
    case MULTICOLOURED:
      glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );
      break;
  }
  
  // re-render game window to reflect the new draw mode
  invalidate();
}

void Viewer::set_speed_mode ( Viewer::SpeedMode mode )
{
  speedMode = mode;
  
  if ( tickConnection.connected() )
  {
    tickConnection.disconnect();
    tickConnection = Glib::signal_timeout().connect(
      sigc::mem_fun(*this, &Viewer::tick), currentSpeedTicksMS[speedMode]);
  }
}

void Viewer::toggle_buffer_mode()
{
  if (DEBUG) std::cerr << "Toggling to Double Buffering: " << (bufferMode == SINGLE) << std::endl;
  
  // Check which mode we are in, toggle to the other one and set up accordingly
  switch( bufferMode )
  {
    case SINGLE:
      bufferMode = DOUBLE;
      glDrawBuffer(GL_BACK);
      break;
    
    case DOUBLE:
      bufferMode = SINGLE;
      glDrawBuffer(GL_FRONT);
      break;
  }
}

void Viewer::onKeypress( guint keyval )
{
  
  switch (keyval)
  {
    case GDK_Left:
      game->moveLeft();
      break;
        
    case GDK_Right :
      game->moveRight();
      break;
      
    case GDK_Down:
      game->rotateCW();
      break;
      
    case GDK_Up:
      game->rotateCCW();
      break;
      
    case GDK_space:
      game->drop();
      break;
  }
  invalidate();
}

void Viewer::draw_beveled_cube_face()
{
  glBegin(GL_QUADS);
  
    // NOTE: this will cause some clipping, but the math is much simpler
    // than if we try to pop the face out than cut the bevels in. might
    // fix this later.
    
    // flat face
    glVertex3d(0.1, 0.1, 0.1);
    glVertex3d(0.1, 0.9, 0.1);
    glVertex3d(0.9, 0.9, 0.1);
    glVertex3d(0.9, 0.1, 0.1);
    
  glEnd();
  
  // beveled edges
  glBegin(GL_QUAD_STRIP);
    
    // left
    glVertex3d(0.0, 0.0, 0.0);
    glVertex3d(0.1, 0.1, 0.1);
    glVertex3d(0.0, 1.0, 0.0);
    glVertex3d(0.1, 0.9, 0.1);
    
    // top
    glVertex3d(1.0, 1.0, 0.0);
    glVertex3d(0.9, 0.9, 0.1);
    
    // right
    glVertex3d(1.0, 0.0, 0.0);
    glVertex3d(0.9, 0.1, 0.1);
    
    // bottom
    glVertex3d(0.0, 0.0, 0.0);
    glVertex3d(0.1, 0.1, 0.1);
    
  glEnd();
}

void Viewer::draw_cube()
{
  // TODO: get current colour, save it?
  
  glPushMatrix();
    // front
    if ( drawMode == MULTICOLOURED) 
      glColor3d(0.0, 0.960784314, 1.0); // turquoise 1
    draw_beveled_cube_face();
    
    // top
    if ( drawMode == MULTICOLOURED) 
      glColor3d(0.0, 0.780392157, 0.549019608); // turquoiseblue

    glRotated( -90.0, 1.0, 0.0, 0.0);
    glTranslated( 0.0, 0.0, 1.0 );
    draw_beveled_cube_face();

    // back
    if ( drawMode == MULTICOLOURED) 
      glColor3d(0.196078431, 0.803921569, 0.196078431); // limegreen
      
    glRotated( -90.0, 1.0, 0.0, 0.0);
    glTranslated( 0.0, 0.0, 1.0 );
    draw_beveled_cube_face();
    
    // bottom
    if ( drawMode == MULTICOLOURED) 
      glColor3d(1.0, 0.843137255, 0.0); // gold 1 (gold)
      
    glRotated( -90.0, 1.0, 0.0, 0.0);
    glTranslated( 0.0, 0.0, 1.0 );
    draw_beveled_cube_face();

    
    // left
    if ( drawMode == MULTICOLOURED) 
      glColor3d(0.0, 0.0, 1.0); // Blue
      
    glRotated( -90.0, 0.0, 1.0, 0.0);
    glTranslated( -1.0, 0.0, 0.0 );
    draw_beveled_cube_face();
    
    // right
    if ( drawMode == MULTICOLOURED) 
      glColor3d(1.0, 0.0, 1.0); // Magenta
      
    glRotated( 180.0, 0.0, 1.0, 0.0);
    glTranslated( -1.0, 0.0, 1.0 );
    draw_beveled_cube_face();
    
  glPopMatrix();
    
  /* Deprecated: un-beveled cube. Save for compatibility mode..?
    glBegin(GL_QUADS);
    // front
    if ( drawMode == MULTICOLOURED) 
      glColor3d(1.0, 0.0, 0.0);
      
    glVertex3d(0.0, 0.0, 0.0);
    glVertex3d(0.0, 1.0, 0.0);
    glVertex3d(1.0, 1.0, 0.0);
    glVertex3d(1.0, 0.0, 0.0);
    
    // top
    if ( drawMode == MULTICOLOURED) 
      glColor3d(0.0, 1.0, 0.0);
      
    glVertex3d(0.0, 1.0, 0.0);
    glVertex3d(0.0, 1.0, 1.0);
    glVertex3d(1.0, 1.0, 1.0);
    glVertex3d(1.0, 1.0, 0.0);
    
    // back
    if ( drawMode == MULTICOLOURED) 
      glColor3d(1.0, 1.0, 0.0);
      
    glVertex3d(0.0, 0.0, 1.0);
    glVertex3d(0.0, 1.0, 1.0);
    glVertex3d(1.0, 1.0, 1.0);
    glVertex3d(1.0, 0.0, 1.0);
    
    // bottom
    if ( drawMode == MULTICOLOURED) 
      glColor3d(0.0, 1.0, 1.0);
      
    glVertex3d(0.0, 0.0, 0.0);
    glVertex3d(0.0, 0.0, 1.0);
    glVertex3d(1.0, 0.0, 1.0);
    glVertex3d(1.0, 0.0, 0.0);
    
    // left
    if ( drawMode == MULTICOLOURED) 
      glColor3d(0.0, 0.0, 1.0);
      
    glVertex3d(0.0, 0.0, 0.0);
    glVertex3d(0.0, 1.0, 0.0);
    glVertex3d(0.0, 1.0, 1.0);
    glVertex3d(0.0, 0.0, 1.0);
    
    // right
    if ( drawMode == MULTICOLOURED) 
      glColor3d(1.0, 0.0, 1.0);
      
    glVertex3d(1.0, 0.0, 0.0);
    glVertex3d(1.0, 1.0, 0.0);
    glVertex3d(1.0, 1.0, 1.0);
    glVertex3d(1.0, 0.0, 1.0);
    
    glEnd();
  */
}

void Viewer::draw_well(){
  // Save the current matrix, move to the starting position of the well
  glPushMatrix();
    glTranslated(-1.0, -1.0, 0.0);
    
    // Grey
    glColor3d(.5, .5, .5);
    
    // Walls
    glPushMatrix();
      for (int i = 0; i < 21; i++)
      {
        // left
        draw_cube();
        
        // right
        glTranslated(11.0, 0.0, 0.0);
        draw_cube();
        
        // back left and up
        glTranslated(-11.0, 0.0, 0.0);
        glTranslated(0.0, 1.0, 0.0);
      }
    glPopMatrix();
    
    // Bottom
    glTranslated(1.0, 0.0, 0.0);
    
    for (int i = 0; i < 10; i++)
    {
      draw_cube();
      glTranslated(1.0, 0.0, 0.0);
    }
    
  glPopMatrix();
}

void Viewer::draw_pieces()
{
  int i,j,p;
  
  glPushMatrix();
    // Get the game board pieces and render them
    for (i=0; i < game_height+4; i++)
    {
      for (j=0; j < game_width; j++)
      {
        p = game->get( i, j );
        if (p >= 0)
        {
          // This is a valid piece, so load its colour and draw it
          glColor3d( pieceColourRGB[p][0], pieceColourRGB[p][1], pieceColourRGB[p][2] );
          draw_cube();
        }
        
        // Move right for next block
        glTranslated(1.0, 0.0, 0.0);
      }
      // Move back left, and up for next row
      glTranslated( -1.0*game_width , 1.0, 0.0);
      
    }
  glPopMatrix();
}

void Viewer::render()
{
  draw_well();
  draw_pieces();
}

bool Viewer::on_expose_event(GdkEventExpose* event)
{
  Glib::RefPtr<Gdk::GL::Drawable> gldrawable = get_gl_drawable();

  if (!gldrawable) return false;

  if (!gldrawable->gl_begin(get_gl_context()))
    return false;

  // Clear the screen

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  // Modify the current projection matrix so that we move the 
  // camera away from the origin.  We'll draw the game at the
  // origin, and we need to back up to see it.

  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
  glTranslated(0.0, 0.0, -40.0);
  
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  // Not implemented: set up lighting (if necessary)

  // Scale and rotate the scene
  persistRotation();
  glMultMatrixd( rotationMatrix->begin() );
  glScaled( scaleParams[0], scaleParams[1], scaleParams[2] );

  // You'll be drawing unit cubes, so the game will have width
  // 10 and height 24 (game = 20, stripe = 4).  Let's translate
  // the game so that we can draw it starting at (0,0) but have
  // it appear centered in the window.
  glTranslated(-5.0, -12.0, 0.0);

  // render the game area
  render();
 
  // We pushed a matrix onto the PROJECTION stack earlier, we 
  // need to pop it.

  glMatrixMode(GL_PROJECTION);
  glPopMatrix();

  // Swap the contents of the front and back buffers so we see what we
  // just drew. This should only be done if double buffering is enabled.
  if ( bufferMode == DOUBLE ) 
    gldrawable->swap_buffers();
  else if ( bufferMode == SINGLE ) 
    glFlush();

  gldrawable->gl_end();

  return true;
}

bool Viewer::on_configure_event(GdkEventConfigure* event)
{
  Glib::RefPtr<Gdk::GL::Drawable> gldrawable = get_gl_drawable();

  if (!gldrawable) return false;
  
  if (!gldrawable->gl_begin(get_gl_context()))
    return false;

  // Set up perspective projection, using current size and aspect
  // ratio of display

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glViewport(0, 0, event->width, event->height);
  gluPerspective(40.0, (GLfloat)event->width/(GLfloat)event->height, 0.1, 1000.0);

  // Reset to modelview matrix mode
  
  glMatrixMode(GL_MODELVIEW);

  gldrawable->gl_end();

  return true;
}

bool Viewer::on_button_press_event(GdkEventButton* event)
{
  // Store this cursor location as previous
  prevCursor.set( event->x, event->time );
  
  // Stop any persisting rotation
  delete prevRotation;
  prevRotation = new Matrix4x4(); // (Identity)
  
  // Drop the time since last mouse release, for persistence's sake
  tLastMouseRelease = 0;
  
  return true;
}

bool Viewer::on_button_release_event(GdkEventButton* event)
{
  double dT, dX;
  
  // The previous x is not dependable for calculating persistence
  // (it seems event->x - prevCursor.x is always 0), so we use the
  // X before that to see if persistence should be stopped, i.e.
  // if mouse was not moving at time of release
  
  // Determine if slash how fast the mouse was moving
  dT = event->time - prevCursor.time;
  dX = event->x - prevCursor.prevX;
  if (dT > 0) dX = dX*10 / dT;
  
  if (DEBUG) std::cerr << "Release: eventX, prevX, prevPrevX, time-tLastMouseRelease: " 
    <<  event->x << ", " <<  prevCursor.x << ", " << prevCursor.prevX << ", " 
    << event->time - tLastMouseRelease << std::endl;
  
  // Don't stop rotating if there was a sufficiently smal time between
  // mouse releases (in the case of multi-dimensional rotation)
  if ( (event->time - tLastMouseRelease) <= 10 )
    return true;
  else
    tLastMouseRelease = event->time;
  
  // Stop rotation if prevX is invalid or dX is too small
  if ( !prevCursor.valid || (-1 <= dX && dX <= 1) )
    prevRotation = new Matrix4x4(); // Identity
    
  // Invalidate the previous cursor location
  prevCursor.invalidate();
  return true;
}

bool Viewer::on_motion_notify_event(GdkEventMotion* event)
{
  double dX, dT;
  bool isScaling = !!(event->state & GDK_SHIFT_MASK);
  
  // Track cursor position if a mouse is pressed
  if (event->state & (GDK_BUTTON1_MASK | GDK_BUTTON2_MASK | GDK_BUTTON3_MASK))
  {
    if ( !prevCursor.valid )
    {
      // We don't have enough information yet to scale or rotate, exit
      prevCursor.set(event->x, event->time);
      return true;
    }
    
    // Get scale/rotation parameters
    dT = event->time - prevCursor.time;
    dX = event->x - prevCursor.x;
    if (dT > 0) dX /= dT;
    
    if (DEBUG) std::cerr << "X, dT: " << dX << ", " << dT << std::endl;
    
    // Update prevCursor
    prevCursor.set(event->x, event->time);
    
    // Rotate or scale the game scene accordingly 
    if (event->state & GDK_BUTTON1_MASK)
      updateTransformations(dX, 'x', isScaling);
      
    if (event->state & GDK_BUTTON2_MASK)
      updateTransformations(dX, 'y', isScaling);
      
    if (event->state & GDK_BUTTON3_MASK)
      updateTransformations(dX, 'z', isScaling);
   
    // re-render game window
    invalidate();
  }
  
  return true;
}

void Viewer::updateTransformations(double dX, char dim, bool isScaling)
{
  double scaleFactor = .07, rotationFactor = .08;
  double scaleMinArr[] = { .3, .3, .3 };
  double scaleMaxArr[] = { 3, 1.2, 5 };
  
  // Rotate or scale the game scene
  if (isScaling)
  {
    // scaling
    if (dim == 'x')
    {
      scaleParams[0] +=  dX*scaleFactor; 
      
      if (scaleParams[0] < scaleMinArr[0])
        scaleParams[0] = scaleMinArr[0];
        
      else if (scaleParams[0] > scaleMaxArr[0])
        scaleParams[0] = scaleMaxArr[0];
    }
      
    if (dim == 'y')
    {
      scaleParams[1] +=  dX*scaleFactor; 
      
      if (scaleParams[1] < scaleMinArr[1])
        scaleParams[1] = scaleMinArr[1];
        
      else if (scaleParams[1] > scaleMaxArr[1])
        scaleParams[1] = scaleMaxArr[1];
    }
      
    if (dim == 'z')
    {
      scaleParams[2] +=  dX*scaleFactor;
      
      if (scaleParams[2] < scaleMinArr[2])
        scaleParams[2] = scaleMinArr[2];
        
      else if (scaleParams[2] > scaleMaxArr[2])
        scaleParams[2] = scaleMaxArr[2];
    }
  }
  else
  {
    // Rotating
    double newRotation[16];
    double theta = dX*rotationFactor;
    double sinT = std::sin(theta);
    double cosT = std::cos(theta);
    
    delete prevRotation;
    prevRotation = new Matrix4x4(); // Identity
    
    
    if (dim == 'x')
    {
      newRotation = 
        {
          1.0,     0.0,     0.0,       0.0,
          0.0,     cosT,    -1*sinT,   0.0,
          0.0,     sinT,    cosT,      0.0,
          0.0,     0.0,     0.0,       1.0
        };
        
 //     *rotationMatrix = 
 //       *rotationMatrix * Matrix4x4( prevRotation ).transpose();
      *prevRotation = *prevRotation * Matrix4x4( newRotation );
    }
        
    if (dim == 'y')
    {
      newRotation = 
        {
          cosT,    0.0,     sinT,      0.0,
          0.0,     1.0,     0.0,       0.0,
          -1*sinT, 0.0,     cosT,      0.0,
          0.0,     0.0,     0.0,       1.0
        };
          
      *prevRotation = *prevRotation * Matrix4x4( newRotation );
    }
      
    if (dim == 'z')
    {
      newRotation = 
        {
          cosT,    -1*sinT, 0.0,       0.0,
          sinT,    cosT,    0.0,       0.0,
          0.0,     0.0,     1.0,       0.0,
          0.0,     0.0,     0.0,       1.0
        };
       
      *prevRotation = *prevRotation * Matrix4x4( newRotation );
    }
    
    // Transpose the rotation mtx so it's in col-major order for Matrix4x4
    *rotationMatrix = rotationMatrix->transpose();
    
    *rotationMatrix = *rotationMatrix * *prevRotation;
    *rotationMatrix = rotationMatrix->transpose();
  }
}

void Viewer::persistRotation()
{
  // Transpose the rotation mtx so it's in col-major order for Matrix4x4
    *rotationMatrix = rotationMatrix->transpose();
    
    *rotationMatrix = *rotationMatrix * *prevRotation;
    *rotationMatrix = rotationMatrix->transpose();
}

void Viewer::speedup()
{
  for (int i=0; i<3; i++)
  {
    currentSpeedTicksMS[i] -= speedupInterval;
    if ( currentSpeedTicksMS[i] < 1 )
      currentSpeedTicksMS[i] = 1;
  }
  
  if ( tickConnection.connected() )
  {
    tickConnection.disconnect();
    tickConnection = Glib::signal_timeout().connect(
      sigc::mem_fun(*this, &Viewer::tick), currentSpeedTicksMS[speedMode]);
  }
}
bool Viewer::tick()
{
  int result;
  
  // Advance the game state
  result = game->tick();
  
  if ( result < 0 )
  {
    std::cerr << "TODO: game over screen? clear field, w/e?\n";
    // animate on game over?
    return false;
  }
  else if (result > 0)
  {
    rowsCompletedSinceSpeedup += result;
    
    if (rowsCompletedSinceSpeedup >= rowsBeforeSpeedup)
    {
      speedup();
      rowsCompletedSinceSpeedup -= rowsBeforeSpeedup;
    }
  }

  // Re-render
  invalidate();
  return true;
}
