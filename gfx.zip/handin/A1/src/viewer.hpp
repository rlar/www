#ifndef CS488_VIEWER_HPP
#define CS488_VIEWER_HPP

#include <gtkmm.h>
#include <gtkglmm.h>
#include "algebra.hpp"
#include "game.hpp"

// The "main" OpenGL widget
class Viewer : public Gtk::GL::DrawingArea {
public:
  Viewer();
  virtual ~Viewer();

  // A useful function that forces this widget to rerender. If you
  // want to render a new frame, do not call on_expose_event
  // directly. Instead call this, which will cause an on_expose_event
  // call when the time is right.
  bool invalidate();
  
  enum DrawMode {
    WIREFRAME,
    FACE,
    MULTICOLOURED
  };
  
  enum SpeedMode {
    SLOW = 0,
    MEDIUM = 1,
    FAST = 2
  };
  
  enum BufferMode {
    SINGLE,
    DOUBLE
  };
  
  // Menu item functionality
  void newgame();
  void reset_game();
  void reset_view();
  void set_draw_mode( Viewer::DrawMode mode );
  void set_speed_mode( Viewer::SpeedMode mode );
  void toggle_buffer_mode();
  
  // Keypress handler for appwindow
  void onKeypress( guint keyval );
  
  
protected:

  // Events we implement
  // Note that we could use gtkmm's "signals and slots" mechanism
  // instead, but for many classes there's a convenient member
  // function one just needs to define that'll be called with the
  // event.

  // Called when GL is first initialized
  virtual void on_realize();
  // Called when our window needs to be redrawn
  virtual bool on_expose_event(GdkEventExpose* event);
  // Called when the window is resized
  virtual bool on_configure_event(GdkEventConfigure* event);
  // Called when a mouse button is pressed
  virtual bool on_button_press_event(GdkEventButton* event);
  // Called when a mouse button is released
  virtual bool on_button_release_event(GdkEventButton* event);
  // Called when the mouse moves
  virtual bool on_motion_notify_event(GdkEventMotion* event);
  
  // Called by the timer; lets us know when to update the game state
  bool tick();
  
  // Rendering procedures
  void render();
  void draw_well();
  void draw_pieces();
  void draw_cube();
  void draw_beveled_cube_face();
  void updateTransformations(double dX, char dim, bool isRotation);
  void persistRotation();
  
  void speedup();

private:
  // Stores information about the last cursor location while
  // a mouse button was held down
  struct PrevCursor {
      int x;
      int prevX;
      int time;
      bool valid;
      
      PrevCursor(){
        invalidate();
      }
      
      void invalidate(){
        x = -1;
        prevX = -1;
        time = -1;
        valid = false;
      }
      void  set( int in_x, int in_time ){
        prevX = x;
        x = in_x;
        time = in_time;
        valid = (prevX >= 0);
      }
    } prevCursor;

  // Stores the scale and rotation information currently associated with
  // the game view, and the previous rotation for persistence
  Matrix4x4* rotationMatrix;
  double scaleParams[3];
  Matrix4x4* prevRotation;
  
  // Stores which modes we are using
  Viewer::BufferMode bufferMode;
  Viewer::DrawMode drawMode;
  Viewer::SpeedMode speedMode;
  
  // Stores the speeds associated with each mode (original and current),
  // and parameters for increasing speed
  //int speedTicksMS[3];
  static const int speedTicksMS[];
  int currentSpeedTicksMS[3];
  
  static const int speedupInterval = 50;
  static const int rowsBeforeSpeedup = 5;
  int rowsCompletedSinceSpeedup;
  
  // Stores the time of last mouse button release, to correct multi
  // -dimensional persistence problems
  double tLastMouseRelease; 
  
  // Stores the colours to use for each of the seven tetrominos
  double pieceColourRGB[7][3];
  
  // Stores the game instance
  Game* game;
  static const double game_width = 10, game_height = 20;
  
  // Stores a reference to the tick signal_timeout handler
  sigc::connection tickConnection;
};

#endif
